import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

class DataProcessor:
    """
    Handles data processing and analysis for the EduTutor platform.
    """
    
    def __init__(self):
        """Initialize the data processor."""
        pass
    
    def calculate_student_statistics(self, student_data):
        """
        Calculate key statistics for a student.
        
        Args:
            student_data: Dictionary containing student performance data
            
        Returns:
            Dictionary with calculated statistics
        """
        performance = student_data.get('performance', {})
        
        # Calculate average performance across subjects
        subject_scores = [
            performance.get('math', 0),
            performance.get('science', 0),
            performance.get('language_arts', 0),
            performance.get('history', 0)
        ]
        
        average_score = sum(subject_scores) / len(subject_scores) if subject_scores else 0
        
        # Identify strongest and weakest subjects
        if subject_scores:
            max_score = max(subject_scores)
            min_score = min(subject_scores)
            
            subjects = ['math', 'science', 'language_arts', 'history']
            strongest_subject = subjects[subject_scores.index(max_score)]
            weakest_subject = subjects[subject_scores.index(min_score)]
        else:
            strongest_subject = "N/A"
            weakest_subject = "N/A"
        
        # Calculate progress metrics
        completed_assessments = student_data.get('completed_assessments', 0)
        total_assessments = student_data.get('total_assessments', 10)  # Default if not provided
        completion_rate = (completed_assessments / total_assessments) * 100 if total_assessments > 0 else 0
        
        return {
            'average_score': average_score,
            'strongest_subject': strongest_subject,
            'weakest_subject': weakest_subject,
            'completion_rate': completion_rate,
            'completed_assessments': completed_assessments,
            'total_assessments': total_assessments
        }
    
    def calculate_class_statistics(self, students_data):
        """
        Calculate statistics for an entire class.
        
        Args:
            students_data: List of dictionaries containing data for each student
            
        Returns:
            Dictionary with calculated class statistics
        """
        if not students_data:
            return {
                'class_average': 0,
                'subject_averages': {},
                'completion_rate': 0,
                'at_risk_count': 0
            }
        
        # Calculate average scores across all students
        all_averages = []
        subject_scores = {
            'math': [],
            'science': [],
            'language_arts': [],
            'history': []
        }
        completion_rates = []
        at_risk_count = 0
        
        for student in students_data:
            # Get student stats
            stats = self.calculate_student_statistics(student)
            all_averages.append(stats['average_score'])
            completion_rates.append(stats['completion_rate'])
            
            # Check if student is at risk (average score < 70)
            if stats['average_score'] < 70:
                at_risk_count += 1
            
            # Collect subject scores
            performance = student.get('performance', {})
            for subject in subject_scores.keys():
                if subject in performance:
                    subject_scores[subject].append(performance[subject])
        
        # Calculate averages
        class_average = sum(all_averages) / len(all_averages) if all_averages else 0
        
        # Calculate subject averages
        subject_averages = {}
        for subject, scores in subject_scores.items():
            subject_averages[subject] = sum(scores) / len(scores) if scores else 0
        
        # Calculate overall completion rate
        avg_completion_rate = sum(completion_rates) / len(completion_rates) if completion_rates else 0
        
        return {
            'class_average': class_average,
            'subject_averages': subject_averages,
            'completion_rate': avg_completion_rate,
            'at_risk_count': at_risk_count,
            'at_risk_percentage': (at_risk_count / len(students_data)) * 100 if students_data else 0
        }
    
    def create_subject_performance_chart(self, data):
        """
        Create a chart showing performance across subjects.
        
        Args:
            data: Dictionary with 'Subject' and 'Score' keys containing lists of values
            
        Returns:
            Plotly figure object
        """
        # Create a bar chart with Plotly
        fig = px.bar(
            data,
            x='Subject',
            y='Score',
            color='Subject',
            text='Score',
            labels={'Score': 'Performance (%)', 'Subject': 'Subject'},
            color_discrete_sequence=px.colors.qualitative.Pastel,
            height=400
        )
        
        # Customize the appearance
        fig.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
        fig.update_layout(
            uniformtext_minsize=8,
            uniformtext_mode='hide',
            xaxis_title="Subject",
            yaxis_title="Performance (%)",
            yaxis=dict(range=[0, 100]),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            margin=dict(l=20, r=20, t=40, b=20),
        )
        
        return fig
    
    def create_progress_over_time_chart(self, data):
        """
        Create a line chart showing progress over time.
        
        Args:
            data: Dictionary with 'Month' and subject keys ('Math', 'Science', etc.)
            
        Returns:
            Plotly figure object
        """
        # Create a line chart with Plotly
        fig = go.Figure()
        
        # Add a line for each subject
        for subject in ['Math', 'Science', 'Language Arts', 'History']:
            if subject in data:
                fig.add_trace(go.Scatter(
                    x=data['Month'],
                    y=data[subject],
                    mode='lines+markers',
                    name=subject
                ))
        
        # Customize the appearance
        fig.update_layout(
            xaxis_title="Month",
            yaxis_title="Score (%)",
            yaxis=dict(range=[0, 100]),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            margin=dict(l=20, r=20, t=40, b=20),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        return fig
    
    def analyze_assessment_responses(self, responses, assessment_data):
        """
        Analyze patterns in assessment responses to identify common areas of difficulty.
        
        Args:
            responses: List of student responses to an assessment
            assessment_data: Data about the assessment structure
            
        Returns:
            Dictionary with analysis results
        """
        if not responses:
            return {
                'participation_rate': 0,
                'average_score': 0,
                'difficult_questions': [],
                'time_analysis': {}
            }
        
        # Calculate participation rate
        total_students = assessment_data.get('total_students', 30)  # Default if not provided
        participation_rate = (len(responses) / total_students) * 100
        
        # Calculate average score
        scores = [r.get('score', 0) for r in responses]
        average_score = sum(scores) / len(scores) if scores else 0
        
        # Identify difficult questions (questions with lowest correct rate)
        question_stats = {}
        for response in responses:
            answers = response.get('answers', {})
            for question_id, answer_data in answers.items():
                if question_id not in question_stats:
                    question_stats[question_id] = {'correct': 0, 'total': 0}
                
                question_stats[question_id]['total'] += 1
                if answer_data.get('is_correct', False):
                    question_stats[question_id]['correct'] += 1
        
        # Calculate correct rate for each question
        for question_id, stats in question_stats.items():
            stats['correct_rate'] = (stats['correct'] / stats['total']) * 100 if stats['total'] > 0 else 0
        
        # Sort questions by correct rate (ascending)
        sorted_questions = sorted(
            question_stats.items(),
            key=lambda x: x[1]['correct_rate']
        )
        
        # Get the 3 most difficult questions
        difficult_questions = [
            {
                'question_id': q_id,
                'correct_rate': stats['correct_rate'],
                'question_text': assessment_data.get('questions', {}).get(q_id, {}).get('text', f"Question {q_id}")
            }
            for q_id, stats in sorted_questions[:3]
        ]
        
        # Analyze completion time
        completion_times = [r.get('completion_time', 0) for r in responses if 'completion_time' in r]
        
        time_analysis = {}
        if completion_times:
            time_analysis = {
                'average_time': sum(completion_times) / len(completion_times),
                'min_time': min(completion_times),
                'max_time': max(completion_times)
            }
        
        return {
            'participation_rate': participation_rate,
            'average_score': average_score,
            'difficult_questions': difficult_questions,
            'time_analysis': time_analysis
        }
    
    def generate_student_recommendations(self, student_data, class_data=None):
        """
        Generate learning recommendations for a student based on their performance.
        
        Args:
            student_data: Dictionary containing student performance data
            class_data: Optional data about the entire class for comparison
            
        Returns:
            List of recommendation dictionaries
        """
        recommendations = []
        stats = self.calculate_student_statistics(student_data)
        
        # Add recommendation for weakest subject
        if stats['weakest_subject'] != "N/A":
            subject = stats['weakest_subject'].capitalize()
            score = student_data.get('performance', {}).get(stats['weakest_subject'], 0)
            
            recommendation = {
                'type': 'improvement',
                'subject': subject,
                'description': f"Focus on improving {subject} skills",
                'details': f"Your current performance in {subject} is {score}%. "
                          f"Consider additional practice in this area."
            }
            recommendations.append(recommendation)
        
        # Add recommendation for completion rate if below 80%
        if stats['completion_rate'] < 80:
            recommendation = {
                'type': 'engagement',
                'subject': 'General',
                'description': "Complete more assignments",
                'details': f"You've completed {stats['completed_assessments']} out of "
                          f"{stats['total_assessments']} assignments. Try to complete "
                          f"all assignments to improve your overall performance."
            }
            recommendations.append(recommendation)
        
        # Add recommendation for strongest subject
        if stats['strongest_subject'] != "N/A":
            subject = stats['strongest_subject'].capitalize()
            
            recommendation = {
                'type': 'enrichment',
                'subject': subject,
                'description': f"Explore advanced {subject} topics",
                'details': f"You're performing well in {subject}. Consider exploring "
                          f"more advanced topics or helping peers in this subject."
            }
            recommendations.append(recommendation)
        
        return recommendations
