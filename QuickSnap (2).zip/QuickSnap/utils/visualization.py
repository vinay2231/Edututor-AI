import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def create_progress_chart(student_data):
    """
    Create a radar chart showing student progress across subjects.
    
    Args:
        student_data: Dictionary containing student performance data
        
    Returns:
        Plotly figure object
    """
    # Extract performance data
    performance = student_data.get('performance', {})
    categories = ['Math', 'Science', 'Language Arts', 'History']
    values = [
        performance.get('math', 0),
        performance.get('science', 0),
        performance.get('language_arts', 0),
        performance.get('history', 0)
    ]
    
    # Create radar chart
    fig = go.Figure()
    
    fig.add_trace(go.Scatterpolar(
        r=values,
        theta=categories,
        fill='toself',
        name='Current Performance',
        line_color='#4B8BF4'
    ))
    
    # Add reference circle at 70% (passing grade)
    fig.add_trace(go.Scatterpolar(
        r=[70, 70, 70, 70],
        theta=categories,
        fill=None,
        name='Passing Grade',
        line=dict(color='red', dash='dash')
    ))
    
    # Customize layout
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 100]
            )
        ),
        showlegend=True,
        margin=dict(l=80, r=80, t=20, b=20),
        height=350
    )
    
    return fig

def create_completion_chart(completion_data):
    """
    Create a progress bar chart showing completion status.
    
    Args:
        completion_data: Dictionary with 'completed' and 'total' values
        
    Returns:
        Plotly figure object
    """
    completed = completion_data.get('completed', 0)
    total = completion_data.get('total', 0)
    
    if total == 0:
        percentage = 0
    else:
        percentage = (completed / total) * 100
    
    # Create a horizontal bar chart
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=[percentage],
        y=['Progress'],
        orientation='h',
        marker=dict(
            color='#4B8BF4',
            line=dict(color='#3B7AF0', width=1)
        ),
        text=f"{percentage:.1f}%",
        textposition='auto',
        hoverinfo='text',
        hovertext=f"Completed {completed} out of {total} assignments"
    ))
    
    # Customize layout
    fig.update_layout(
        xaxis=dict(
            range=[0, 100],
            title="Completion (%)",
            showgrid=True,
            gridcolor='#EEEEEE'
        ),
        yaxis=dict(
            showticklabels=True,
            title=""
        ),
        margin=dict(l=20, r=20, t=10, b=30),
        height=150,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    
    return fig

def create_performance_comparison(student_score, class_average, national_average=None):
    """
    Create a bar chart comparing student performance with class and national averages.
    
    Args:
        student_score: The student's score
        class_average: The class average score
        national_average: Optional national average score
        
    Returns:
        Plotly figure object
    """
    data = {
        'Category': ['Your Score', 'Class Average'],
        'Score': [student_score, class_average]
    }
    
    if national_average is not None:
        data['Category'].append('National Average')
        data['Score'].append(national_average)
    
    # Create a bar chart
    fig = px.bar(
        data,
        x='Category',
        y='Score',
        color='Category',
        text='Score',
        labels={'Score': 'Score (%)', 'Category': ''},
        color_discrete_sequence=['#4B8BF4', '#7FB2F0', '#A8C4F5'],
        height=300
    )
    
    # Customize the appearance
    fig.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
    fig.update_layout(
        uniformtext_minsize=8,
        uniformtext_mode='hide',
        yaxis=dict(range=[0, 100]),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        margin=dict(l=20, r=20, t=20, b=20),
        showlegend=False
    )
    
    return fig

def create_learning_path_visualization(learning_path):
    """
    Create a visual representation of a student's learning path.
    
    Args:
        learning_path: Dictionary containing learning path data
        
    Returns:
        Plotly figure object
    """
    # Extract module data
    modules = learning_path.get('modules', [])
    if not modules:
        # Create empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No learning path modules available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False,
            font=dict(size=14)
        )
        fig.update_layout(height=300)
        return fig
    
    # Create data for visualization
    module_names = [module.get('name', f"Module {i+1}") for i, module in enumerate(modules)]
    difficulty_levels = [module.get('difficulty', 1) for module in modules]
    prerequisites = [len(module.get('prerequisites', [])) for module in modules]
    estimated_time = [module.get('estimated_time', 1) for module in modules]
    
    # Normalize values for sizing
    max_time = max(estimated_time) if estimated_time else 1
    size_values = [30 + (time / max_time) * 30 for time in estimated_time]
    
    # Create custom color scale based on difficulty
    colors = ['#B3E5FC', '#81D4FA', '#4FC3F7', '#29B6F6', '#03A9F4', 
              '#039BE5', '#0288D1', '#0277BD', '#01579B', '#014377']
    
    # Create a scatter plot
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=list(range(len(module_names))),
        y=difficulty_levels,
        mode='markers+text',
        text=module_names,
        textposition='top center',
        marker=dict(
            size=size_values,
            color=[colors[min(d-1, 9)] for d in difficulty_levels],
            line=dict(width=1, color='#888')
        ),
        hovertemplate='<b>%{text}</b><br>' +
                      'Difficulty: %{y}<br>' +
                      'Prerequisites: %{marker.size}<br>' +
                      '<extra></extra>'
    ))
    
    # Add connections between modules based on prerequisites
    for i, module in enumerate(modules):
        prereq_ids = module.get('prerequisite_ids', [])
        for prereq_id in prereq_ids:
            # Find the index of the prerequisite module
            prereq_index = next((j for j, m in enumerate(modules) if m.get('id') == prereq_id), None)
            
            if prereq_index is not None:
                fig.add_shape(
                    type="line",
                    x0=prereq_index,
                    y0=difficulty_levels[prereq_index],
                    x1=i,
                    y1=difficulty_levels[i],
                    line=dict(color="#888", width=1, dash="dot")
                )
    
    # Customize layout
    fig.update_layout(
        xaxis=dict(
            showticklabels=False,
            title="Learning Path Progression"
        ),
        yaxis=dict(
            title="Difficulty Level",
            range=[0, max(difficulty_levels) + 1]
        ),
        margin=dict(l=20, r=20, t=20, b=20),
        height=400,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        showlegend=False
    )
    
    return fig

def create_engagement_chart(engagement_data):
    """
    Create a chart visualizing student engagement metrics.
    
    Args:
        engagement_data: Dictionary with engagement metrics
        
    Returns:
        Plotly figure object
    """
    # Create a subplot with 2 vertical charts
    fig = make_subplots(rows=2, cols=1, 
                        subplot_titles=("Weekly Logins", "Time Spent Per Session"))
    
    # Weekly logins chart (line chart)
    if 'weekly_logins' in engagement_data:
        weeks = list(engagement_data['weekly_logins'].keys())
        login_counts = list(engagement_data['weekly_logins'].values())
        
        fig.add_trace(
            go.Scatter(
                x=weeks,
                y=login_counts,
                mode='lines+markers',
                name='Logins',
                line=dict(color='#4B8BF4', width=2)
            ),
            row=1, col=1
        )
    
    # Time spent chart (bar chart)
    if 'time_spent' in engagement_data:
        dates = list(engagement_data['time_spent'].keys())
        minutes = list(engagement_data['time_spent'].values())
        
        fig.add_trace(
            go.Bar(
                x=dates,
                y=minutes,
                name='Minutes',
                marker=dict(color='#4B8BF4')
            ),
            row=2, col=1
        )
    
    # Customize layout
    fig.update_layout(
        height=500,
        margin=dict(l=20, r=20, t=60, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        showlegend=False
    )
    
    # Update axes
    fig.update_yaxes(title_text="Login Count", row=1, col=1)
    fig.update_yaxes(title_text="Minutes", row=2, col=1)
    
    return fig
