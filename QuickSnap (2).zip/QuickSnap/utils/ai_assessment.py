import os
import langchain
from langchain_community.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from utils.openai_integration import grade_essay, check_openai_available

class AIAssessmentEngine:
    """
    Handles AI-powered assessment and feedback generation
    using IBM Generative LLM model (simulated here with OpenAI).
    """
    
    def __init__(self):
        """Initialize the AI assessment engine."""
        # In a real implementation, this would use the IBM Generative LLM
        # For this demo, we'll use OpenAI as a stand-in
        api_key = os.getenv("OPENAI_API_KEY", "")
        self.has_api_key = bool(api_key)
        
        if self.has_api_key:
            self.llm = OpenAI(
                api_key=api_key,
                temperature=0.3
            )
        else:
            # No API key available - we'll use fallback methods
            self.llm = None
    
    def evaluate_multiple_choice(self, student_answers, correct_answers):
        """
        Evaluate multiple choice questions.
        
        Args:
            student_answers: Dict of student's answers {question_id: answer}
            correct_answers: Dict of correct answers {question_id: answer}
            
        Returns:
            Dict with score and feedback
        """
        correct_count = 0
        feedback = {}
        
        for question_id, correct_answer in correct_answers.items():
            student_answer = student_answers.get(question_id)
            is_correct = student_answer == correct_answer
            
            if is_correct:
                correct_count += 1
                feedback[question_id] = "Correct!"
            else:
                feedback[question_id] = f"Incorrect. The correct answer is {correct_answer}."
        
        score = (correct_count / len(correct_answers)) * 100
        
        return {
            "score": score,
            "feedback": feedback,
            "correct_count": correct_count,
            "total_questions": len(correct_answers)
        }
    
    def evaluate_short_answer(self, student_answer, question, rubric):
        """
        Evaluate a short answer response using the LLM.
        
        Args:
            student_answer: The student's text response
            question: The question that was asked
            rubric: Grading criteria
            
        Returns:
            Dict with score and detailed feedback
        """
        # If no API key is available, provide simulated feedback
        if not self.has_api_key:
            # Generate a score based on answer length and complexity
            # This is just a simulation - in a real system, we'd connect to an actual AI service
            words = len(student_answer.split())
            base_score = min(85, max(65, 60 + words // 5))  # Basic scoring based on length
            
            return {
                "score": base_score,
                "feedback": (
                    "Your answer demonstrates understanding of the key concepts. \n\n"
                    "Strengths:\n- Good use of terminology\n- Clear explanation\n\n"
                    "Areas for Improvement:\n- Consider providing more specific examples\n"
                    "- Expand on how these concepts connect to broader themes"
                )
            }
        
        # If API key is available, use the LLM for evaluation
        prompt_template = PromptTemplate(
            input_variables=["question", "answer", "rubric"],
            template="""
            Evaluate the following student answer based on the provided rubric.
            
            Question: {question}
            Student Answer: {answer}
            Rubric Criteria: {rubric}
            
            Score (0-100):
            Feedback:
            Strengths:
            Areas for Improvement:
            """
        )
        
        chain = LLMChain(llm=self.llm, prompt=prompt_template)
        
        try:
            result = chain.run(question=question, answer=student_answer, rubric=rubric)
            
            # Parse the result to extract score and feedback
            lines = result.strip().split('\n')
            score_line = next((line for line in lines if line.startswith("Score")), "")
            score = int(score_line.split(':')[1].strip().split('-')[0]) if score_line else 70
            
            feedback = '\n'.join([line for line in lines if not line.startswith("Score")])
            
            return {
                "score": score,
                "feedback": feedback
            }
        except Exception as e:
            # Fallback in case of API failure
            return {
                "score": 70,
                "feedback": "Your answer covers the main points of the question with good clarity. Consider adding more specific details and examples to strengthen your response."
            }
    
    def evaluate_essay(self, essay_text, prompt, criteria):
        """
        Evaluate an essay using our AI-powered grading system.
        
        Args:
            essay_text: The student's essay
            prompt: The essay prompt
            criteria: Dictionary or string of grading criteria and weights
            
        Returns:
            Dict with overall score, criteria scores, and detailed feedback
        """
        # Convert criteria to dictionary if it's a string
        criteria_dict = {}
        if isinstance(criteria, str):
            # Parse criteria string into a dictionary
            for line in criteria.strip().split('\n'):
                if line.strip():
                    # Try to extract weights from formats like "Content (30%)"
                    import re
                    match = re.search(r'(.*?)\s*\((\d+)%\)', line.strip())
                    if match:
                        criteria_name = match.group(1).strip()
                        weight = int(match.group(2))
                        criteria_dict[criteria_name] = weight
                    else:
                        # If no weight is specified, assign equal weights
                        criteria_dict[line.strip()] = 100 // (len(criteria.strip().split('\n')))
        else:
            # Assume criteria is already a dictionary
            criteria_dict = criteria
        
        # Use the new OpenAI integration for essay grading
        if check_openai_available():
            # Call the dedicated essay grading function
            result = grade_essay(essay_text, prompt, criteria_dict)
            
            return {
                "overall_score": result.get("overall_score", 75),
                "criteria_scores": result.get("criteria_scores", {}),
                "strengths": result.get("strengths", []),
                "areas_for_improvement": result.get("areas_for_improvement", []),
                "detailed_feedback": result.get("detailed_feedback", "")
            }
        
        # If OpenAI integration is not available, provide simulated feedback
        import random
        criteria_scores = {}
        
        # Generate scores for each criterion based on essay length and complexity
        words = len(essay_text.split())
        base_quality = min(90, max(70, 65 + words // 50))
        
        for criterion, weight in criteria_dict.items():
            # Add some variation to scores
            variation = random.randint(-5, 5)
            score = min(95, max(65, base_quality + variation))
            criteria_scores[criterion] = score
        
        # Calculate weighted overall score
        if criteria_scores:
            total_weight = sum(criteria_dict.values())
            overall_score = sum(criteria_scores[criterion] * (criteria_dict[criterion] / total_weight) 
                              for criterion in criteria_scores) if total_weight > 0 else 75
        else:
            overall_score = 75
        
        # Round to nearest integer
        overall_score = round(overall_score)
        
        # Generate detailed feedback
        detailed_feedback = (
            "Overall Assessment:\n"
            f"This essay addresses the prompt with {['adequate', 'good', 'strong'][random.randint(0, 2)]} "
            f"arguments and {['could use more', 'includes some', 'provides solid'][random.randint(0, 2)]} "
            "supporting evidence. The organization is logical, though transitions between some paragraphs "
            "could be improved.\n\n"
            
            "Criterion Breakdown:\n"
        )
        
        strengths = [
            "Clear thesis statement that addresses the prompt",
            "Effective use of evidence to support key points",
            "Well-structured paragraphs with clear topic sentences"
        ]
        
        areas_for_improvement = [
            "Continue developing your thesis with more specific examples",
            "Consider addressing counterarguments to strengthen your position",
            "Review your conclusion to ensure it effectively summarizes your main points"
        ]
        
        for criterion, score in criteria_scores.items():
            quality = "needs improvement" if score < 75 else "meets expectations" if score < 85 else "exceeds expectations"
            detailed_feedback += f"- {criterion}: {score}/100 - {quality}\n"
        
        detailed_feedback += (
            "\nRecommendations:\n" + 
            "\n".join(f"- {improvement}" for improvement in areas_for_improvement)
        )
        
        return {
            "overall_score": overall_score,
            "criteria_scores": criteria_scores,
            "strengths": strengths,
            "areas_for_improvement": areas_for_improvement,
            "detailed_feedback": detailed_feedback
        }
    
    def generate_personalized_feedback(self, assessment_results, student_data):
        """
        Generate personalized feedback and recommendations based on assessment results.
        
        Args:
            assessment_results: Results from various assessments
            student_data: Historical data about the student
            
        Returns:
            Dict with feedback and personalized recommendations
        """
        strengths = []
        areas_for_improvement = []
        recommendations = []
        
        # Analyze the assessment results
        # In a real implementation, this would use more sophisticated analysis
        for assessment_id, result in assessment_results.items():
            if result.get("score", 0) >= 85:
                strengths.append(f"Strong performance in {result.get('subject', 'this subject')}")
            elif result.get("score", 0) <= 70:
                areas_for_improvement.append(f"Needs improvement in {result.get('subject', 'this subject')}")
        
        # Add strengths/weaknesses based on student historical data if available
        if student_data and 'performance' in student_data:
            for subject, score in student_data['performance'].items():
                if score >= 85 and not any(subject.lower() in s.lower() for s in strengths):
                    strengths.append(f"Consistently strong in {subject.capitalize()}")
                elif score <= 70 and not any(subject.lower() in s.lower() for s in areas_for_improvement):
                    areas_for_improvement.append(f"Consistent challenge with {subject.capitalize()}")
        
        # Generate personalized recommendations based on performance
        if not self.has_api_key or not areas_for_improvement:
            # Generate rule-based recommendations without API
            if areas_for_improvement:
                # Recommendations for improvement
                for area in areas_for_improvement:
                    subject = area.split("in ")[-1].strip().lower()
                    if "math" in subject:
                        recommendations.extend([
                            "Complete the interactive Math practice problems focusing on your weaker topics",
                            "Watch the concept explanation videos with step-by-step solutions",
                            "Schedule regular 20-minute practice sessions instead of longer, infrequent study periods"
                        ])
                    elif "science" in subject:
                        recommendations.extend([
                            "Review the key science concepts using the visual learning materials",
                            "Practice connecting theoretical knowledge to real-world applications",
                            "Create your own simple experiments to reinforce scientific principles"
                        ])
                    elif "language" in subject:
                        recommendations.extend([
                            "Read diverse texts daily to improve comprehension and vocabulary",
                            "Practice writing short responses focusing on structure and clarity",
                            "Actively participate in discussion groups to develop communication skills"
                        ])
                    elif "history" in subject:
                        recommendations.extend([
                            "Create timelines to visualize historical relationships and sequences",
                            "Focus on understanding cause-and-effect relationships between events",
                            "Use memory techniques like association to remember key dates and figures"
                        ])
                    else:
                        recommendations.extend([
                            "Dedicate more time to practicing difficult topics",
                            "Try different learning approaches that match your preferred learning style",
                            "Break complex topics into smaller, manageable parts"
                        ])
            else:
                # Recommendations for advancing already strong performance
                if strengths:
                    subject = strengths[0].split("in ")[-1].strip().lower()
                    if "math" in subject:
                        recommendations.extend([
                            "Explore advanced mathematical concepts beyond the curriculum",
                            "Consider participating in math competitions or challenges",
                            "Apply your math skills to interdisciplinary projects"
                        ])
                    elif "science" in subject:
                        recommendations.extend([
                            "Design and conduct your own research projects",
                            "Connect with online scientific communities to explore current research",
                            "Mentor peers who might be struggling with science concepts"
                        ])
                    else:
                        recommendations.extend([
                            "Challenge yourself with advanced materials",
                            "Consider peer tutoring to reinforce your knowledge",
                            "Explore related topics to broaden your understanding"
                        ])
                else:
                    recommendations = [
                        "Maintain consistent study habits across all subjects",
                        "Set specific learning goals for each week",
                        "Diversify your learning resources to gain different perspectives",
                        "Apply knowledge through practical projects"
                    ]
            
            # Remove duplicate recommendations and limit to 3-5
            unique_recommendations = []
            for rec in recommendations:
                if rec not in unique_recommendations:
                    unique_recommendations.append(rec)
            recommendations = unique_recommendations[:5]
            
        else:
            # If API key available, use LLM for personalized recommendations
            prompt_template = PromptTemplate(
                input_variables=["strengths", "areas_for_improvement", "student_data"],
                template="""
                Generate 3-5 personalized learning recommendations for a student with the following profile:
                
                Student Information:
                {student_data}
                
                Strengths:
                {strengths}
                
                Areas Needing Improvement:
                {areas_for_improvement}
                
                Provide specific, actionable recommendations that will help this student improve in the identified areas
                while leveraging their strengths. Format each recommendation as a bullet point.
                
                Recommendations:
                """
            )
            
            chain = LLMChain(llm=self.llm, prompt=prompt_template)
            
            try:
                recommendations_text = chain.run(
                    strengths='\n'.join(strengths),
                    areas_for_improvement='\n'.join(areas_for_improvement),
                    student_data=str(student_data)
                )
                
                # Parse bullet points
                recommendations = [line.strip().replace('- ', '') 
                                 for line in recommendations_text.split('\n') 
                                 if line.strip().startswith('-')]
                
                # If no recommendations were found, provide fallbacks
                if not recommendations:
                    recommendations = [
                        "Review core concepts in subjects with scores below 75%",
                        "Allocate more study time to challenging topics",
                        "Consider seeking additional help for problem areas"
                    ]
            except Exception as e:
                recommendations = [
                    "Review core concepts in subjects with scores below 75%",
                    "Allocate more study time to challenging topics",
                    "Consider seeking additional help for problem areas"
                ]
        
        return {
            "strengths": strengths,
            "areas_for_improvement": areas_for_improvement,
            "recommendations": recommendations
        }
    
    def generate_learning_path(self, student_performance, learning_style):
        """
        Generate a personalized learning path based on student performance and learning style.
        
        Args:
            student_performance: Dict with performance metrics by subject
            learning_style: The student's preferred learning style
            
        Returns:
            Dict with structured learning path recommendations
        """
        # Identify subjects that need the most attention
        sorted_subjects = sorted(student_performance.items(), key=lambda x: x[1])
        priority_subjects = sorted_subjects[:2]  # Focus on the two weakest subjects
        
        learning_modules = []
        
        # For each priority subject, recommend appropriate modules
        for subject, score in priority_subjects:
            # Basic module recommendations based on performance level
            if score < 60:
                level = "Foundational"
            elif score < 80:
                level = "Intermediate"
            else:
                level = "Advanced"
            
            # Adapt module format to learning style
            if learning_style == "Visual":
                format_preference = "visual materials like diagrams, videos, and infographics"
                resources = [
                    "Video tutorials with visual explanations",
                    "Concept maps and graphic organizers",
                    "Interactive diagrams and simulations"
                ]
            elif learning_style == "Auditory":
                format_preference = "lectures, discussions, and audio materials"
                resources = [
                    "Recorded lectures with expert explanations",
                    "Interactive discussion groups",
                    "Audio summaries of key concepts"
                ]
            elif learning_style == "Reading/Writing":
                format_preference = "textbooks, articles, and written exercises"
                resources = [
                    "Comprehensive reading materials with examples",
                    "Writing exercises to reinforce concepts",
                    "Practice worksheets with detailed solutions"
                ]
            else:  # Kinesthetic
                format_preference = "hands-on activities, experiments, and interactive exercises"
                resources = [
                    "Hands-on labs and practical activities",
                    "Interactive simulations and experiments",
                    "Real-world problem-solving exercises"
                ]
            
            # Subject-specific content
            if subject == "math":
                subject_name = "Mathematics"
                topic_focus = "Algebraic concepts" if level == "Foundational" else "Functions and graphs" if level == "Intermediate" else "Advanced calculus concepts"
            elif subject == "science":
                subject_name = "Science"
                topic_focus = "Scientific method and basic principles" if level == "Foundational" else "Chemistry and physics fundamentals" if level == "Intermediate" else "Advanced biology and laboratory techniques"
            elif subject == "language_arts":
                subject_name = "Language Arts"
                topic_focus = "Grammar and basic composition" if level == "Foundational" else "Essay structure and analysis" if level == "Intermediate" else "Advanced literary analysis and research writing"
            elif subject == "history":
                subject_name = "History"
                topic_focus = "Chronological understanding and key events" if level == "Foundational" else "Historical analysis and cause-effect relationships" if level == "Intermediate" else "Historical interpretations and historiography"
            else:
                subject_name = subject.capitalize()
                topic_focus = f"{level} concepts and skills"
            
            module = {
                "subject": subject_name,
                "level": level,
                "topic_focus": topic_focus,
                "format_preference": format_preference,
                "estimated_duration": "3-4 weeks",
                "recommended_resources": resources
            }
            
            learning_modules.append(module)
        
        # Add additional information based on learning style
        if learning_style == "Visual":
            study_tips = [
                "Use color-coding in your notes to organize information",
                "Create mind maps to visualize connections between concepts",
                "Watch educational videos before reading text materials"
            ]
        elif learning_style == "Auditory":
            study_tips = [
                "Record and listen to your own summaries of key concepts",
                "Participate actively in study groups and discussions",
                "Read materials aloud to enhance understanding"
            ]
        elif learning_style == "Reading/Writing":
            study_tips = [
                "Rewrite notes in your own words to reinforce learning",
                "Create detailed outlines for complex topics",
                "Practice explaining concepts in writing before tests"
            ]
        else:  # Kinesthetic
            study_tips = [
                "Take short, active breaks during study sessions",
                "Create physical models or representations when possible",
                "Use flashcards or movable elements for studying sequences"
            ]
        
        return {
            "priority_subjects": [module["subject"] for module in learning_modules],
            "learning_modules": learning_modules,
            "estimated_completion_time": "6-8 weeks",
            "learning_style_adaptations": f"Materials optimized for {learning_style} learning",
            "study_tips": study_tips
        }
