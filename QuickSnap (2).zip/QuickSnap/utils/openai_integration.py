import os
import json
import streamlit as st
from openai import OpenAI

# The newest OpenAI model is "gpt-4o" which was released May 13, 2024.
# Do not change this unless explicitly requested by the user
DEFAULT_MODEL = "gpt-4o"

def get_openai_client():
    """
    Get OpenAI client using the API key from environment variables.
    
    Returns:
        OpenAI client instance or None if API key is not available
    """
    api_key = os.environ.get("OPENAI_API_KEY")
    
    if api_key:
        return OpenAI(api_key=api_key)
    else:
        return None

def check_openai_available():
    """
    Check if OpenAI integration is available.
    
    Returns:
        bool: True if OpenAI API key is available, False otherwise
    """
    return os.environ.get("OPENAI_API_KEY") is not None

def grade_essay(essay_text, prompt, criteria):
    """
    Grade an essay submission using OpenAI.
    
    Args:
        essay_text (str): The student's essay text
        prompt (str): The original essay prompt
        criteria (dict): Dictionary with grading criteria and their weights
        
    Returns:
        dict: Grading results including score, criteria_scores, and detailed feedback
    """
    client = get_openai_client()
    
    if not client:
        # Fallback to mock grading if OpenAI integration is not available
        return mock_grade_essay(essay_text, prompt, criteria)
    
    # Prepare the grading criteria as a formatted string
    criteria_text = "\n".join([f"- {name} ({weight}%)" for name, weight in criteria.items()])
    
    # Create the system prompt for GPT
    system_prompt = f"""
    You are an expert essay grader with years of experience in education. 
    Evaluate the student essay based on the following criteria:
    
    {criteria_text}
    
    Provide a detailed analysis and scoring for each criterion. 
    Be fair, objective, and constructive in your evaluation. 
    
    Return your evaluation as a JSON object with the following structure:
    {{
        "overall_score": (integer between 0 and 100),
        "criteria_scores": {{
            "criterion1": (score between 0 and 100),
            "criterion2": (score between 0 and 100),
            ...
        }},
        "strengths": [
            "strength1",
            "strength2",
            ...
        ],
        "areas_for_improvement": [
            "area1",
            "area2",
            ...
        ],
        "detailed_feedback": "comprehensive paragraph with detailed assessment"
    }}
    """
    
    # Create the user prompt with the essay information
    user_prompt = f"""
    Essay Prompt: {prompt}
    
    Student Essay:
    {essay_text}
    
    Please grade this essay based on the criteria provided.
    """
    
    try:
        # Call the OpenAI API
        response = client.chat.completions.create(
            model=DEFAULT_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"}
        )
        
        # Parse the response
        result = json.loads(response.choices[0].message.content)
        
        # Validate and ensure all required fields are present
        if "overall_score" not in result:
            result["overall_score"] = 75  # Default score if missing
            
        if "criteria_scores" not in result:
            result["criteria_scores"] = {criterion: 75 for criterion in criteria.keys()}
            
        if "strengths" not in result:
            result["strengths"] = ["Clear effort shown in the essay"]
            
        if "areas_for_improvement" not in result:
            result["areas_for_improvement"] = ["Continue developing your writing skills"]
            
        if "detailed_feedback" not in result:
            result["detailed_feedback"] = "The essay shows understanding of the topic but could be improved with more detailed analysis."
            
        return result
        
    except Exception as e:
        st.error(f"Error during essay grading: {str(e)}")
        # Fall back to mock grading if the API call fails
        return mock_grade_essay(essay_text, prompt, criteria)

def mock_grade_essay(essay_text, prompt, criteria):
    """
    Provide a mock grading response when OpenAI integration is not available.
    
    Args:
        essay_text (str): The student's essay text
        prompt (str): The original essay prompt
        criteria (dict): Dictionary with grading criteria and their weights
        
    Returns:
        dict: Mock grading results
    """
    # Calculate a simple score based on essay length (this is just a basic heuristic)
    word_count = len(essay_text.split())
    base_score = min(85, max(60, word_count / 10))  # Score between 60-85 based on length
    
    # Generate mock criteria scores with some variation
    import random
    criteria_scores = {
        criterion: min(100, max(50, base_score + random.randint(-10, 10)))
        for criterion in criteria.keys()
    }
    
    # Calculate overall score as weighted average
    overall_score = sum(
        criteria_scores[criterion] * (weight / 100)
        for criterion, weight in criteria.items()
    )
    
    # Round to nearest integer
    overall_score = round(overall_score)
    
    return {
        "overall_score": overall_score,
        "criteria_scores": criteria_scores,
        "strengths": [
            "Clear structure with introduction, body, and conclusion",
            "Good use of vocabulary appropriate to the topic",
            "Demonstrates understanding of the core concepts"
        ],
        "areas_for_improvement": [
            "Further develop arguments with more specific examples",
            "Strengthen transitions between paragraphs",
            "Enhance critical analysis of the subject matter"
        ],
        "detailed_feedback": (
            "The essay demonstrates a solid understanding of the topic and presents "
            "arguments in a logical structure. The introduction effectively sets up "
            "the main thesis, and the conclusion summarizes the key points. "
            "To improve, consider incorporating more specific examples and evidence "
            "to support your arguments, and develop a deeper analysis of the subject matter. "
            "Pay attention to paragraph transitions to enhance the overall flow of your writing."
        )
    }

def analyze_writing_patterns(essays, student_id):
    """
    Analyze writing patterns across multiple essays from the same student.
    
    Args:
        essays (list): List of essay texts from the student
        student_id (str): The student's ID for reference
        
    Returns:
        dict: Analysis results including strengths, weaknesses, and growth areas
    """
    client = get_openai_client()
    
    if not client or not essays:
        return {
            "recurring_strengths": ["Clear organization of ideas"],
            "recurring_issues": ["Consider expanding vocabulary usage"],
            "growth_areas": ["Focus on developing more nuanced arguments"],
            "writing_style": "Structured and methodical, with strong organizational skills"
        }
    
    # Truncate essays if they're very long to fit in context window
    essays_sample = [essay[:1000] + "..." if len(essay) > 1000 else essay for essay in essays]
    essays_text = "\n\n--- ESSAY BREAK ---\n\n".join(essays_sample)
    
    system_prompt = """
    You are an expert writing coach who analyzes student writing patterns across multiple essays.
    Based on the provided essays from the same student, identify:
    
    1. Recurring strengths in their writing
    2. Consistent issues or challenges they face
    3. Areas where they could focus to improve their writing skills
    4. An overall assessment of their writing style
    
    Return your analysis as a JSON object with the following structure:
    {
        "recurring_strengths": ["strength1", "strength2", ...],
        "recurring_issues": ["issue1", "issue2", ...],
        "growth_areas": ["area1", "area2", ...],
        "writing_style": "description of overall writing style"
    }
    """
    
    user_prompt = f"""
    The following are multiple essays written by student ID {student_id}. 
    Each essay is separated by "--- ESSAY BREAK ---".
    
    {essays_text}
    
    Please analyze these essays to identify patterns in the student's writing.
    """
    
    try:
        response = client.chat.completions.create(
            model=DEFAULT_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"}
        )
        
        return json.loads(response.choices[0].message.content)
        
    except Exception as e:
        st.error(f"Error during writing pattern analysis: {str(e)}")
        return {
            "recurring_strengths": ["Clear organization of ideas"],
            "recurring_issues": ["Consider expanding vocabulary usage"],
            "growth_areas": ["Focus on developing more nuanced arguments"],
            "writing_style": "Structured and methodical, with strong organizational skills"
        }

def generate_writing_tips(student_id, analysis=None):
    """
    Generate personalized writing tips based on student's past performance.
    
    Args:
        student_id (str): The student's ID
        analysis (dict, optional): Previous analysis results if available
        
    Returns:
        list: Personalized writing tips
    """
    client = get_openai_client()
    
    if not client:
        return [
            "Structure your essays with clear introduction, body paragraphs, and conclusion",
            "Use transitional phrases to connect ideas between paragraphs",
            "Support claims with specific examples and evidence",
            "Vary sentence structure to maintain reader engagement",
            "Revise and edit your work to eliminate grammatical errors"
        ]
    
    system_prompt = """
    You are an experienced writing instructor who provides personalized advice to students.
    Based on the information about the student's writing patterns, generate 5 specific, 
    actionable tips that will help them improve their writing skills.
    
    Each tip should be targeted to address their specific challenges while building on their strengths.
    Return your tips as a JSON array of strings.
    """
    
    if analysis:
        analysis_text = json.dumps(analysis)
    else:
        analysis_text = """
        {
            "recurring_strengths": ["Clear organization of ideas", "Good understanding of basic concepts"],
            "recurring_issues": ["Limited vocabulary", "Repetitive sentence structures", "Lack of detailed examples"],
            "growth_areas": ["Critical analysis", "Argument development", "Evidence incorporation"],
            "writing_style": "Structured but could benefit from more varied expression and deeper analysis"
        }
        """
    
    user_prompt = f"""
    Here is an analysis of writing patterns for student ID {student_id}:
    
    {analysis_text}
    
    Based on this analysis, please provide 5 personalized, actionable writing tips for this student.
    """
    
    try:
        response = client.chat.completions.create(
            model=DEFAULT_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        
        if isinstance(result, list):
            return result
        elif "tips" in result:
            return result["tips"]
        else:
            # Try to extract a list from whatever we got
            for key, value in result.items():
                if isinstance(value, list) and len(value) > 0:
                    return value
            
            # Fallback
            return [
                "Structure your essays with clear introduction, body paragraphs, and conclusion",
                "Use transitional phrases to connect ideas between paragraphs",
                "Support claims with specific examples and evidence",
                "Vary sentence structure to maintain reader engagement",
                "Revise and edit your work to eliminate grammatical errors"
            ]
            
    except Exception as e:
        st.error(f"Error generating writing tips: {str(e)}")
        return [
            "Structure your essays with clear introduction, body paragraphs, and conclusion",
            "Use transitional phrases to connect ideas between paragraphs",
            "Support claims with specific examples and evidence",
            "Vary sentence structure to maintain reader engagement",
            "Revise and edit your work to eliminate grammatical errors"
        ]