def get_all_students():
    """
    Get a list of all student data.
    
    Returns:
        List of student dictionaries
    """
    students = [
        {
            "id": "S1001",
            "first_name": "Emma",
            "last_name": "Johnson",
            "grade_level": 10,
            "learning_style": "Visual",
            "completed_assessments": 12,
            "performance": {
                "math": 85,
                "science": 92,
                "language_arts": 88,
                "history": 78
            },
            "engagement": {
                "math": 7,
                "science": 9,
                "language_arts": 8,
                "history": 6
            }
        },
        {
            "id": "S1002",
            "first_name": "Michael",
            "last_name": "Smith",
            "grade_level": 10,
            "learning_style": "Kinesthetic",
            "completed_assessments": 10,
            "performance": {
                "math": 72,
                "science": 68,
                "language_arts": 85,
                "history": 80
            },
            "engagement": {
                "math": 5,
                "science": 6,
                "language_arts": 8,
                "history": 7
            }
        },
        {
            "id": "S1003",
            "first_name": "Sophia",
            "last_name": "Garcia",
            "grade_level": 10,
            "learning_style": "Auditory",
            "completed_assessments": 14,
            "performance": {
                "math": 95,
                "science": 90,
                "language_arts": 92,
                "history": 94
            },
            "engagement": {
                "math": 9,
                "science": 8,
                "language_arts": 9,
                "history": 9
            }
        },
        {
            "id": "S1004",
            "first_name": "Jacob",
            "last_name": "Wilson",
            "grade_level": 10,
            "learning_style": "Reading/Writing",
            "completed_assessments": 8,
            "performance": {
                "math": 65,
                "science": 72,
                "language_arts": 80,
                "history": 68
            },
            "engagement": {
                "math": 4,
                "science": 6,
                "language_arts": 7,
                "history": 5
            }
        },
        {
            "id": "S1005",
            "first_name": "Olivia",
            "last_name": "Martinez",
            "grade_level": 10,
            "learning_style": "Visual",
            "completed_assessments": 11,
            "performance": {
                "math": 78,
                "science": 85,
                "language_arts": 90,
                "history": 82
            },
            "engagement": {
                "math": 6,
                "science": 8,
                "language_arts": 9,
                "history": 7
            }
        },
        {
            "id": "S1006",
            "first_name": "Ethan",
            "last_name": "Brown",
            "grade_level": 10,
            "learning_style": "Kinesthetic",
            "completed_assessments": 9,
            "performance": {
                "math": 88,
                "science": 75,
                "language_arts": 70,
                "history": 73
            },
            "engagement": {
                "math": 8,
                "science": 6,
                "language_arts": 5,
                "history": 6
            }
        },
        {
            "id": "S1007",
            "first_name": "Ava",
            "last_name": "Taylor",
            "grade_level": 10,
            "learning_style": "Auditory",
            "completed_assessments": 13,
            "performance": {
                "math": 82,
                "science": 88,
                "language_arts": 93,
                "history": 85
            },
            "engagement": {
                "math": 7,
                "science": 8,
                "language_arts": 9,
                "history": 7
            }
        }
    ]
    
    return students

def get_student_data(student_id):
    """
    Get data for a specific student.
    
    Args:
        student_id: The ID of the student to retrieve
        
    Returns:
        Student dictionary or None if not found
    """
    students = get_all_students()
    
    for student in students:
        if student["id"] == student_id:
            return student
    
    return None
