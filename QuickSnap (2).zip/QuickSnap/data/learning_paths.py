def get_default_learning_paths():
    """
    Get default learning paths for different subjects and levels.
    
    Returns:
        Dictionary of learning paths by subject and level
    """
    learning_paths = {
        "math": {
            "beginner": {
                "modules": [
                    {
                        "id": "m1001",
                        "name": "Number Basics",
                        "description": "Understanding integers, decimals, and fractions",
                        "difficulty": 1,
                        "estimated_time": 3,  # hours
                        "prerequisite_ids": []
                    },
                    {
                        "id": "m1002",
                        "name": "Basic Operations",
                        "description": "Addition, subtraction, multiplication, and division",
                        "difficulty": 2,
                        "estimated_time": 4,
                        "prerequisite_ids": ["m1001"]
                    },
                    {
                        "id": "m1003",
                        "name": "Order of Operations",
                        "description": "PEMDAS and solving multi-step problems",
                        "difficulty": 3,
                        "estimated_time": 3,
                        "prerequisite_ids": ["m1002"]
                    }
                ]
            },
            "intermediate": {
                "modules": [
                    {
                        "id": "m2001",
                        "name": "Algebraic Expressions",
                        "description": "Variables, terms, and simplifying expressions",
                        "difficulty": 4,
                        "estimated_time": 4,
                        "prerequisite_ids": ["m1003"]
                    },
                    {
                        "id": "m2002",
                        "name": "Linear Equations",
                        "description": "Solving one and two-step equations",
                        "difficulty": 5,
                        "estimated_time": 5,
                        "prerequisite_ids": ["m2001"]
                    },
                    {
                        "id": "m2003",
                        "name": "Linear Functions",
                        "description": "Graphing, slope, and intercepts",
                        "difficulty": 6,
                        "estimated_time": 6,
                        "prerequisite_ids": ["m2002"]
                    }
                ]
            },
            "advanced": {
                "modules": [
                    {
                        "id": "m3001",
                        "name": "Quadratic Equations",
                        "description": "Solving and graphing quadratic equations",
                        "difficulty": 7,
                        "estimated_time": 6,
                        "prerequisite_ids": ["m2003"]
                    },
                    {
                        "id": "m3002",
                        "name": "Polynomial Functions",
                        "description": "Higher-degree polynomials and their properties",
                        "difficulty": 8,
                        "estimated_time": 7,
                        "prerequisite_ids": ["m3001"]
                    },
                    {
                        "id": "m3003",
                        "name": "Trigonometry Basics",
                        "description": "Sine, cosine, tangent, and the unit circle",
                        "difficulty": 9,
                        "estimated_time": 8,
                        "prerequisite_ids": ["m3002"]
                    }
                ]
            }
        },
        "science": {
            "beginner": {
                "modules": [
                    {
                        "id": "s1001",
                        "name": "Scientific Method",
                        "description": "Understanding the process of scientific inquiry",
                        "difficulty": 1,
                        "estimated_time": 2,
                        "prerequisite_ids": []
                    },
                    {
                        "id": "s1002",
                        "name": "States of Matter",
                        "description": "Solids, liquids, gases, and phase changes",
                        "difficulty": 2,
                        "estimated_time": 3,
                        "prerequisite_ids": ["s1001"]
                    },
                    {
                        "id": "s1003",
                        "name": "Basic Cell Biology",
                        "description": "Cell structure and function",
                        "difficulty": 3,
                        "estimated_time": 4,
                        "prerequisite_ids": ["s1002"]
                    }
                ]
            },
            "intermediate": {
                "modules": [
                    {
                        "id": "s2001",
                        "name": "Chemical Reactions",
                        "description": "Balancing equations and reaction types",
                        "difficulty": 4,
                        "estimated_time": 5,
                        "prerequisite_ids": ["s1003"]
                    },
                    {
                        "id": "s2002",
                        "name": "Genetics Fundamentals",
                        "description": "DNA, genes, and inheritance patterns",
                        "difficulty": 5,
                        "estimated_time": 6,
                        "prerequisite_ids": ["s2001"]
                    },
                    {
                        "id": "s2003",
                        "name": "Forces and Motion",
                        "description": "Newton's laws and basic mechanics",
                        "difficulty": 6,
                        "estimated_time": 5,
                        "prerequisite_ids": ["s2002"]
                    }
                ]
            },
            "advanced": {
                "modules": [
                    {
                        "id": "s3001",
                        "name": "Organic Chemistry",
                        "description": "Carbon compounds and their reactions",
                        "difficulty": 7,
                        "estimated_time": 7,
                        "prerequisite_ids": ["s2003"]
                    },
                    {
                        "id": "s3002",
                        "name": "Cellular Respiration",
                        "description": "Energy processes in cells",
                        "difficulty": 8,
                        "estimated_time": 6,
                        "prerequisite_ids": ["s3001"]
                    },
                    {
                        "id": "s3003",
                        "name": "Electromagnetic Spectrum",
                        "description": "Properties and applications of EM waves",
                        "difficulty": 9,
                        "estimated_time": 8,
                        "prerequisite_ids": ["s3002"]
                    }
                ]
            }
        },
        "language_arts": {
            "beginner": {
                "modules": [
                    {
                        "id": "l1001",
                        "name": "Grammar Basics",
                        "description": "Parts of speech and sentence structure",
                        "difficulty": 1,
                        "estimated_time": 3,
                        "prerequisite_ids": []
                    },
                    {
                        "id": "l1002",
                        "name": "Reading Comprehension",
                        "description": "Identifying main ideas and supporting details",
                        "difficulty": 2,
                        "estimated_time": 4,
                        "prerequisite_ids": ["l1001"]
                    },
                    {
                        "id": "l1003",
                        "name": "Basic Essay Structure",
                        "description": "Introduction, body paragraphs, and conclusion",
                        "difficulty": 3,
                        "estimated_time": 4,
                        "prerequisite_ids": ["l1002"]
                    }
                ]
            },
            "intermediate": {
                "modules": [
                    {
                        "id": "l2001",
                        "name": "Literary Devices",
                        "description": "Similes, metaphors, symbolism, and more",
                        "difficulty": 4,
                        "estimated_time": 5,
                        "prerequisite_ids": ["l1003"]
                    },
                    {
                        "id": "l2002",
                        "name": "Argumentative Writing",
                        "description": "Constructing logical arguments with evidence",
                        "difficulty": 5,
                        "estimated_time": 6,
                        "prerequisite_ids": ["l2001"]
                    },
                    {
                        "id": "l2003",
                        "name": "Text Analysis",
                        "description": "Critical reading and interpretation",
                        "difficulty": 6,
                        "estimated_time": 5,
                        "prerequisite_ids": ["l2002"]
                    }
                ]
            },
            "advanced": {
                "modules": [
                    {
                        "id": "l3001",
                        "name": "Advanced Rhetoric",
                        "description": "Persuasive techniques and stylistic choices",
                        "difficulty": 7,
                        "estimated_time": 6,
                        "prerequisite_ids": ["l2003"]
                    },
                    {
                        "id": "l3002",
                        "name": "Literary Criticism",
                        "description": "Different approaches to analyzing literature",
                        "difficulty": 8,
                        "estimated_time": 7,
                        "prerequisite_ids": ["l3001"]
                    },
                    {
                        "id": "l3003",
                        "name": "Research Writing",
                        "description": "Academic research and citation methods",
                        "difficulty": 9,
                        "estimated_time": 8,
                        "prerequisite_ids": ["l3002"]
                    }
                ]
            }
        },
        "history": {
            "beginner": {
                "modules": [
                    {
                        "id": "h1001",
                        "name": "Historical Thinking",
                        "description": "Chronology, causality, and evidence",
                        "difficulty": 1,
                        "estimated_time": 2,
                        "prerequisite_ids": []
                    },
                    {
                        "id": "h1002",
                        "name": "Ancient Civilizations",
                        "description": "Early human societies and their developments",
                        "difficulty": 2,
                        "estimated_time": 4,
                        "prerequisite_ids": ["h1001"]
                    },
                    {
                        "id": "h1003",
                        "name": "Middle Ages",
                        "description": "European and global developments from 500-1500 CE",
                        "difficulty": 3,
                        "estimated_time": 4,
                        "prerequisite_ids": ["h1002"]
                    }
                ]
            },
            "intermediate": {
                "modules": [
                    {
                        "id": "h2001",
                        "name": "Renaissance and Reformation",
                        "description": "Cultural and religious transformations in Europe",
                        "difficulty": 4,
                        "estimated_time": 5,
                        "prerequisite_ids": ["h1003"]
                    },
                    {
                        "id": "h2002",
                        "name": "Age of Exploration",
                        "description": "Global connections and colonial expansion",
                        "difficulty": 5,
                        "estimated_time": 4,
                        "prerequisite_ids": ["h2001"]
                    },
                    {
                        "id": "h2003",
                        "name": "Industrial Revolution",
                        "description": "Technological and social changes",
                        "difficulty": 6,
                        "estimated_time": 5,
                        "prerequisite_ids": ["h2002"]
                    }
                ]
            },
            "advanced": {
                "modules": [
                    {
                        "id": "h3001",
                        "name": "World Wars",
                        "description": "Global conflicts and their impacts",
                        "difficulty": 7,
                        "estimated_time": 6,
                        "prerequisite_ids": ["h2003"]
                    },
                    {
                        "id": "h3002",
                        "name": "Cold War Era",
                        "description": "Superpower rivalry and global implications",
                        "difficulty": 8,
                        "estimated_time": 6,
                        "prerequisite_ids": ["h3001"]
                    },
                    {
                        "id": "h3003",
                        "name": "Contemporary History",
                        "description": "Post-1990 developments and globalization",
                        "difficulty": 9,
                        "estimated_time": 7,
                        "prerequisite_ids": ["h3002"]
                    }
                ]
            }
        }
    }
    
    return learning_paths

def get_personalized_learning_path(student_data):
    """
    Generate a personalized learning path based on student performance data.
    
    Args:
        student_data: Dictionary containing student performance data
        
    Returns:
        Dictionary with personalized learning path
    """
    # Get default learning paths
    default_paths = get_default_learning_paths()
    
    # Determine student level for each subject
    levels = {}
    for subject, score in student_data['performance'].items():
        if score < 70:
            levels[subject] = "beginner"
        elif score < 85:
            levels[subject] = "intermediate"
        else:
            levels[subject] = "advanced"
    
    # Create personalized path by selecting appropriate modules
    personalized_path = {
        "student_id": student_data["id"],
        "learning_style": student_data["learning_style"],
        "subjects": {}
    }
    
    for subject, level in levels.items():
        if subject in default_paths and level in default_paths[subject]:
            personalized_path["subjects"][subject] = {
                "level": level,
                "modules": default_paths[subject][level]["modules"]
            }
    
    # Sort subjects by priority (lowest scoring subjects first)
    sorted_subjects = sorted(
        student_data['performance'].items(),
        key=lambda x: x[1]
    )
    
    personalized_path["priority_subjects"] = [subject for subject, _ in sorted_subjects[:2]]
    
    return personalized_path
