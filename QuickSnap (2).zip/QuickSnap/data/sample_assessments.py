def get_available_assessments():
    """
    Get a list of available assessments.
    
    Returns:
        List of assessment dictionaries
    """
    assessments = [
        {
            "id": "math_quiz_1",
            "title": "Algebra Fundamentals Quiz",
            "subject": "Math",
            "type": "Quiz",
            "description": "A quiz covering basic algebraic concepts including equations, inequalities, and functions.",
            "due_date": "2023-06-15",
            "estimated_time": 30,
            "questions": [
                {
                    "id": "q1",
                    "type": "multiple_choice",
                    "text": "Solve for x: 2x + 5 = 13",
                    "options": ["x = 4", "x = 9", "x = 3", "x = 6"],
                    "correct_answer": "x = 4"
                },
                {
                    "id": "q2",
                    "type": "multiple_choice",
                    "text": "Which of the following is a linear function?",
                    "options": ["y = x²", "y = 3x + 2", "y = 1/x", "y = 2^x"],
                    "correct_answer": "y = 3x + 2"
                },
                {
                    "id": "q3",
                    "type": "true_false",
                    "text": "The solution to the inequality x > 5 includes the value x = 5.",
                    "correct_answer": "False"
                },
                {
                    "id": "q4",
                    "type": "short_answer",
                    "text": "Explain the difference between an expression and an equation.",
                    "sample_answer": "An expression is a mathematical phrase with numbers, variables, and operators, but does not contain an equals sign. An equation contains an equals sign and states that two expressions are equal."
                }
            ]
        },
        {
            "id": "science_lab_1",
            "title": "Scientific Method Lab Report",
            "subject": "Science",
            "type": "Lab",
            "description": "Complete a lab report for your experiment on photosynthesis. Include your hypothesis, methodology, results, and conclusions.",
            "due_date": "2023-06-20",
            "estimated_time": 60,
            "instructions": "Write a complete lab report following the scientific method. Include your initial hypothesis, detailed methodology, observed results, and conclusions drawn from the experiment.",
            "deliverables": "A comprehensive lab report document including any charts, graphs, or images documenting your experiment."
        },
        {
            "id": "history_essay_1",
            "title": "Industrial Revolution Impact Essay",
            "subject": "History",
            "type": "Essay",
            "description": "Write an analytical essay on the social and economic impacts of the Industrial Revolution on European society.",
            "due_date": "2023-06-25",
            "estimated_time": 90,
            "prompt": "Analyze the social and economic impacts of the Industrial Revolution on European society during the 18th and 19th centuries. Consider factors such as urbanization, working conditions, class structure, and economic growth.",
            "word_count_min": 750,
            "word_count_max": 1200,
            "criteria": "Thesis (25%)\nHistorical Evidence (30%)\nAnalysis (25%)\nOrganization (10%)\nGrammar and Style (10%)"
        },
        {
            "id": "language_arts_project_1",
            "title": "Literary Analysis Project",
            "subject": "Language Arts",
            "type": "Project",
            "description": "Create a multimedia presentation analyzing themes, characters, and literary devices in the novel we read this quarter.",
            "due_date": "2023-06-30",
            "estimated_time": 120,
            "instructions": "Develop a presentation that analyzes the major themes, character development, and literary devices in the assigned novel. Your analysis should be supported by specific examples from the text.",
            "deliverables": "A digital presentation (slides or video) and a written analysis document of at least 500 words."
        },
        {
            "id": "math_test_1",
            "title": "Geometry Concepts Test",
            "subject": "Math",
            "type": "Test",
            "description": "A comprehensive test covering geometric concepts including angles, triangles, circles, and area/volume calculations.",
            "due_date": "2023-07-05",
            "estimated_time": 45
        }
    ]
    
    return assessments

def get_assessment_by_id(assessment_id):
    """
    Get a specific assessment by ID.
    
    Args:
        assessment_id: The ID of the assessment to retrieve
        
    Returns:
        Assessment dictionary or None if not found
    """
    assessments = get_available_assessments()
    
    for assessment in assessments:
        if assessment["id"] == assessment_id:
            return assessment
    
    return None
