import streamlit as st
import time
import random
from utils.ai_assessment import AIAssessmentEngine
from data.sample_assessments import get_assessment_by_id
from data.student_data import get_student_data

# Custom CSS to enhance assessment page design
st.markdown("""
<style>
    /* Assessment page specific styles */
    .assessment-header {
        background-color: #4B8BF4;
        background-image: linear-gradient(135deg, #4B8BF4, #3267d6);
        color: white;
        padding: 2rem;
        border-radius: 0.8rem;
        margin-bottom: 2rem;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    
    .assessment-header h1 {
        margin: 0;
        color: white;
        font-size: 2.2rem;
    }
    
    .assessment-header p {
        color: rgba(255, 255, 255, 0.9);
        margin: 0.5rem 0 0 0;
        font-size: 1.1rem;
    }
    
    .assessment-card {
        background-color: white;
        border-radius: 0.5rem;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    
    .assessment-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    .meta-item {
        background-color: #f8f9fa;
        padding: 0.5rem 1rem;
        border-radius: 0.5rem;
        display: flex;
        align-items: center;
        font-size: 0.9rem;
    }
    
    .meta-icon {
        margin-right: 0.5rem;
        color: #4B8BF4;
    }
    
    .question-card {
        background-color: white;
        border-radius: 0.5rem;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        border-left: 4px solid #4B8BF4;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    
    .question-number {
        font-size: 1.1rem;
        font-weight: 600;
        color: #4B8BF4;
        margin-bottom: 0.8rem;
    }
    
    .feedback-card {
        background-color: white;
        border-radius: 0.5rem;
        border-left: 4px solid #4B8BF4;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    
    .result-header {
        display: flex;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    .score-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        font-weight: 600;
        margin-right: 1.5rem;
    }
    
    .score-high {
        background-color: #e6f4ea;
        color: #34A853;
        border: 2px solid #34A853;
    }
    
    .score-medium {
        background-color: #fef7e0;
        color: #FBBC05;
        border: 2px solid #FBBC05;
    }
    
    .score-low {
        background-color: #fce8e6;
        color: #EA4335;
        border: 2px solid #EA4335;
    }
    
    .criteria-list {
        margin: 1rem 0;
    }
    
    .criteria-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.8rem;
        padding-bottom: 0.8rem;
        border-bottom: 1px solid #f0f2f6;
    }
    
    .criteria-name {
        font-weight: 500;
    }
    
    .criteria-score {
        font-weight: 600;
        padding: 0.2rem 0.5rem;
        border-radius: 0.3rem;
    }
    
    .timer-bar {
        background-color: #f0f2f6;
        height: 8px;
        border-radius: 4px;
        margin: 0.5rem 0 1.5rem 0;
        overflow: hidden;
    }
    
    .timer-progress {
        height: 100%;
        background-color: #4B8BF4;
        border-radius: 4px;
    }
    
    .feedback-section {
        margin-top: 1.5rem;
        padding-top: 1.5rem;
        border-top: 1px solid #f0f2f6;
    }
    
    .feedback-item {
        margin-bottom: 1rem;
        padding-left: 1rem;
        border-left: 3px solid;
    }
    
    .feedback-strength {
        border-color: #34A853;
    }
    
    .feedback-improvement {
        border-color: #FBBC05;
    }
    
    .button-container {
        display: flex;
        gap: 1rem;
        margin-top: 1.5rem;
    }
</style>
""", unsafe_allow_html=True)

def app():
    """Assessment page for students to take assessments and view feedback."""
    
    # Check if user is authenticated and is a student
    if not st.session_state.get('authenticated', False) or st.session_state.get('user_type') != 'student':
        st.warning("Please log in as a student to access assessments.")
        return
    
    # Get current assessment ID from session state or query parameters
    assessment_id = st.session_state.get('current_assessment')
    
    if not assessment_id:
        st.info("No assessment selected. Please select an assessment from the dashboard.")
        if st.button("Return to Dashboard"):
            st.session_state.page = "dashboard"
            st.rerun()
        return
    
    # Get assessment data
    assessment = get_assessment_by_id(assessment_id)
    
    if not assessment:
        st.error("Assessment not found.")
        if st.button("Return to Dashboard"):
            st.session_state.page = "dashboard"
            st.rerun()
        return
    
    # Get student data
    student_id = st.session_state.current_user
    student_data = get_student_data(student_id)
    
    # Modern page header
    subject_color = "#4285F4" if assessment['subject'] == "Math" else "#34A853" if assessment['subject'] == "Science" else "#FBBC05" if assessment['subject'] == "Language Arts" else "#EA4335"
    
    st.markdown(f"""
    <div class="assessment-header">
        <h1>{assessment['title']}</h1>
        <p>{assessment['description']}</p>
        
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1.5rem; flex-wrap: wrap; gap: 1rem;">
            <div style="background: rgba(255,255,255,0.2); padding: 0.5rem 1rem; border-radius: 0.5rem; backdrop-filter: blur(5px);">
                <div style="font-size: 0.8rem; opacity: 0.8;">Subject</div>
                <div style="font-size: 1.1rem; font-weight: 500;">{assessment['subject']}</div>
            </div>
            <div style="background: rgba(255,255,255,0.2); padding: 0.5rem 1rem; border-radius: 0.5rem; backdrop-filter: blur(5px);">
                <div style="font-size: 0.8rem; opacity: 0.8;">Estimated Time</div>
                <div style="font-size: 1.1rem; font-weight: 500;">{assessment['estimated_time']} minutes</div>
            </div>
            <div style="background: rgba(255,255,255,0.2); padding: 0.5rem 1rem; border-radius: 0.5rem; backdrop-filter: blur(5px);">
                <div style="font-size: 0.8rem; opacity: 0.8;">Due Date</div>
                <div style="font-size: 1.1rem; font-weight: 500;">{assessment['due_date']}</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if assessment is already submitted
    if st.session_state.get(f"submitted_{assessment_id}", False):
        show_feedback(assessment, student_data)
        return
    
    # Assessment submission state
    if st.session_state.get(f"submitting_{assessment_id}", False):
        show_submission_progress(assessment, student_data)
        return
    
    # Initialize form for assessment submission with modern UI
    with st.form(key=f"assessment_form_{assessment_id}"):
        if assessment['type'] in ["Quiz", "Test"]:
            # Modern section header for questions
            st.markdown("""
            <h2 style="display: flex; align-items: center; margin: 1.5rem 0 1.2rem 0;">
                <span style="background-color: #4B8BF4; color: white; height: 32px; width: 32px; 
                    border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; 
                    margin-right: 0.5rem; font-size: 1rem;">❓</span>
                Assessment Questions
            </h2>
            """, unsafe_allow_html=True)
            
            # Display quiz/test questions with enhanced styling
            questions = assessment.get('questions', [])
            
            for i, question in enumerate(questions):
                # Modern question card
                st.markdown(f"""
                <div class="question-card">
                    <div class="question-number">Question {i+1}</div>
                    <div style="font-size: 1rem; margin-bottom: 1rem; color: #333;">{question['text']}</div>
                </div>
                """, unsafe_allow_html=True)
                
                if question['type'] == "multiple_choice":
                    options = question['options']
                    st.session_state[f"q{i}_answer"] = st.radio(
                        "Select your answer:",
                        options,
                        key=f"q{i}"
                    )
                elif question['type'] == "true_false":
                    st.session_state[f"q{i}_answer"] = st.radio(
                        "Select your answer:",
                        ["True", "False"],
                        key=f"q{i}"
                    )
                elif question['type'] == "short_answer":
                    st.session_state[f"q{i}_answer"] = st.text_area(
                        "Your answer:",
                        height=120,
                        key=f"q{i}",
                        help="Write a concise answer focused on the key points."
                    )
        
        elif assessment['type'] == "Essay":
            # Modern essay section header
            st.markdown("""
            <h2 style="display: flex; align-items: center; margin: 1.5rem 0 1.2rem 0;">
                <span style="background-color: #4B8BF4; color: white; height: 32px; width: 32px; 
                    border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; 
                    margin-right: 0.5rem; font-size: 1rem;">📝</span>
                Essay Assignment
            </h2>
            """, unsafe_allow_html=True)
            
            # Essay prompt in a card
            prompt = assessment.get('prompt', 'Write your essay below.')
            word_min = assessment.get('word_count_min', 500)
            word_max = assessment.get('word_count_max', 1000)
            
            st.markdown(f"""
            <div class="question-card">
                <div style="font-weight: 600; font-size: 1.05rem; margin-bottom: 0.8rem; color: #333;">Essay Prompt</div>
                <div style="font-size: 1rem; margin-bottom: 1rem; color: #333;">{prompt}</div>
                <div style="background-color: #f8f9fa; border-radius: 0.5rem; padding: 0.8rem; font-size: 0.9rem; color: #555;">
                    <div style="display: flex; align-items: center;">
                        <span style="color: #4B8BF4; margin-right: 0.5rem;">ℹ️</span> 
                        <span>Word count requirement: <strong>{word_min}-{word_max} words</strong></span>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Essay text area
            st.session_state[f"essay_text"] = st.text_area(
                "Your essay:",
                height=300,
                key="essay_content",
                help="Write a well-structured essay that addresses all aspects of the prompt."
            )
            
            # Word count display with modern styling
            if st.session_state[f"essay_text"]:
                word_count = len(st.session_state[f"essay_text"].split())
                
                # Color based on whether count is within range
                count_color = "#34A853" if word_min <= word_count <= word_max else "#FBBC05" if word_count < word_min else "#EA4335"
                
                # Visualize progress toward word count
                progress_pct = min(100, int((word_count / word_min) * 100)) if word_count < word_min else 100
                
                st.markdown(f"""
                <div style="margin: 1rem 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <div style="font-size: 0.9rem; color: #555;">Word Count:</div>
                        <div style="font-weight: 600; color: {count_color};">{word_count}/{word_min}-{word_max}</div>
                    </div>
                    <div class="timer-bar">
                        <div class="timer-progress" style="width: {progress_pct}%; background-color: {count_color};"></div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                if word_count < word_min:
                    st.warning(f"Your essay is {word_min - word_count} words below the minimum requirement.")
                elif word_count > word_max:
                    st.warning(f"Your essay is {word_count - word_max} words above the maximum limit.")
                else:
                    st.success(f"Your word count is within the required range.")
        
        elif assessment['type'] in ["Project", "Lab"]:
            # Modern project/lab section header
            st.markdown("""
            <h2 style="display: flex; align-items: center; margin: 1.5rem 0 1.2rem 0;">
                <span style="background-color: #4B8BF4; color: white; height: 32px; width: 32px; 
                    border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; 
                    margin-right: 0.5rem; font-size: 1rem;">🔬</span>
                Project Submission
            </h2>
            """, unsafe_allow_html=True)
            
            # Project instructions in a card
            instructions = assessment.get('instructions', 'Complete the project according to the requirements.')
            deliverables = assessment.get('deliverables', 'Submit your completed work below.')
            
            st.markdown(f"""
            <div class="question-card">
                <div style="font-weight: 600; font-size: 1.05rem; margin-bottom: 0.8rem; color: #333;">Project Instructions</div>
                <div style="font-size: 1rem; margin-bottom: 1.2rem; color: #333;">{instructions}</div>
                
                <div style="font-weight: 600; font-size: 1.05rem; margin-bottom: 0.8rem; color: #333;">Deliverables</div>
                <div style="font-size: 1rem; margin-bottom: 1rem; color: #333;">{deliverables}</div>
                
                <div style="background-color: #e8f0fe; border-radius: 0.5rem; padding: 0.8rem; font-size: 0.9rem; color: #555; border-left: 3px solid #4285F4;">
                    <div style="display: flex; align-items: center;">
                        <span style="color: #4285F4; margin-right: 0.5rem;">💡</span> 
                        <span>Your submission should demonstrate your understanding of key concepts and your ability to apply them to solve real-world problems.</span>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Section for project description/report
            st.markdown("""
            <div style="margin: 1.5rem 0 1rem 0;">
                <div style="font-weight: 500; font-size: 1.05rem; color: #333;">Project Report</div>
                <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">
                    Describe your approach, methodology, and key findings.
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Text submission with improved styling
            st.session_state[f"project_text"] = st.text_area(
                "Project Description / Lab Report:",
                height=250,
                key="project_content",
                help="Include your methodology, findings, and conclusions. Be specific about how you approached the problem."
            )
            
            # File upload section with modern styling
            st.markdown("""
            <div style="margin: 1.5rem 0 1rem 0;">
                <div style="font-weight: 500; font-size: 1.05rem; color: #333;">Project Files</div>
                <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">
                    Upload any relevant files, such as code, data, or presentations.
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # File upload (in a real app - here we'll just simulate)
            col1, col2 = st.columns([3, 1])
            with col1:
                upload_file = st.file_uploader(
                    "Upload your project files (simulation only)",
                    type=["pdf", "docx", "txt", "zip", "py", "ipynb", "csv"],
                    key="project_file"
                )
            
            # Show uploaded file with better styling
            if upload_file:
                st.markdown(f"""
                <div style="background-color: #f8f9fa; border-radius: 0.5rem; padding: 0.8rem; 
                    margin-top: 0.5rem; font-size: 0.9rem; border-left: 3px solid #34A853;">
                    <div style="display: flex; align-items: center;">
                        <span style="color: #34A853; margin-right: 0.5rem;">✅</span> 
                        <span>File <strong>{upload_file.name}</strong> uploaded successfully</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        
        # Modern submit section with progress reminders
        st.markdown("""
        <div style="margin: 2rem 0 1rem 0;">
            <div style="font-weight: 500; font-size: 1.05rem; color: #333; margin-bottom: 0.5rem;">
                Ready to Submit?
            </div>
            <div style="font-size: 0.9rem; color: #666; margin-bottom: 1rem;">
                Please review all your answers carefully before submitting. Once submitted, you cannot make changes.
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Submit button with modern styling
        col1, col2 = st.columns([1, 1])
        with col1:
            # Cancel button (secondary style)
            if st.form_submit_button("Cancel and Return to Dashboard", type="secondary", use_container_width=True):
                st.session_state.page = "dashboard"
                st.rerun()
        
        with col2:
            # Submit button (primary style)
            submit_button = st.form_submit_button("Submit Assessment", type="primary", use_container_width=True)
        
        if submit_button:
            st.session_state[f"submitting_{assessment_id}"] = True
            st.rerun()

def show_submission_progress(assessment, student_data):
    """Show assessment submission and grading progress with modern UI."""
    
    # Create a visually appealing submission process
    st.markdown(f"""
    <div class="assessment-header">
        <h1>Processing Your Assessment</h1>
        <p>Our AI is analyzing your submission and preparing personalized feedback</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Modern progress card
    st.markdown("""
    <div class="assessment-card">
        <div style="font-weight: 600; margin-bottom: 1rem; font-size: 1.1rem; color: #333;">
            Assessment Evaluation in Progress
        </div>
    """, unsafe_allow_html=True)
    
    # Show progress bar with modern styling
    progress_bar = st.progress(0)
    
    # Create stages of the process
    stages = [
        {"percent": 30, "message": "Validating your submission", "icon": "🔍"},
        {"percent": 60, "message": "Running AI assessment", "icon": "🧠"},
        {"percent": 90, "message": "Generating personalized feedback", "icon": "📊"},
        {"percent": 100, "message": "Finalizing results", "icon": "✅"}
    ]
    
    # Track completed stages
    completed_stages = []
    current_stage = 0
    
    # Simulate submission and AI grading process with visual feedback
    for i in range(101):
        time.sleep(0.05)  # Simulate processing time
        progress_bar.progress(i)
        
        # Check if we've reached a new stage
        for stage_idx, stage in enumerate(stages):
            if i >= stage["percent"] and stage_idx == current_stage:
                # Add to completed stages
                completed_stages.append(stage)
                current_stage += 1
                
                # Show stage completion message
                st.markdown(f"""
                <div style="display: flex; align-items: center; margin: 0.8rem 0;">
                    <div style="background-color: #4B8BF4; color: white; height: 32px; width: 32px; 
                        border-radius: 50%; display: flex; align-items: center; justify-content: center; 
                        margin-right: 0.8rem; font-size: 1.2rem;">{stage["icon"]}</div>
                    <div style="color: #333;">{stage["message"]}</div>
                </div>
                """, unsafe_allow_html=True)
    
    # Close the assessment card div
    st.markdown("""
    </div>
    """, unsafe_allow_html=True)
    
    # Mark as submitted
    assessment_id = assessment['id']
    st.session_state[f"submitted_{assessment_id}"] = True
    
    # Simulate AI assessment
    ai_engine = AIAssessmentEngine()
    
    if assessment['type'] in ["Quiz", "Test"]:
        # For quiz/test, generate sample results
        questions = assessment.get('questions', [])
        student_answers = {}
        correct_answers = {}
        
        for i, question in enumerate(questions):
            student_answers[f"q{i}"] = st.session_state.get(f"q{i}_answer", "")
            correct_answers[f"q{i}"] = question.get('correct_answer', "")
        
        # Store result in session state
        st.session_state[f"result_{assessment_id}"] = ai_engine.evaluate_multiple_choice(
            student_answers, correct_answers
        )
    
    elif assessment['type'] == "Essay":
        # For essays, simulate AI evaluation
        essay_text = st.session_state.get(f"essay_text", "")
        prompt = assessment.get('prompt', '')
        criteria = assessment.get('criteria', 'Content (30%)\nOrganization (25%)\nLanguage (25%)\nCritical Thinking (20%)')
        
        # Store result in session state
        st.session_state[f"result_{assessment_id}"] = ai_engine.evaluate_essay(
            essay_text, prompt, criteria
        )
    
    elif assessment['type'] in ["Project", "Lab"]:
        # For projects/labs, simulate a more general evaluation
        project_text = st.session_state.get(f"project_text", "")
        
        # Generate a simple score between 70-95
        import random
        score = random.randint(70, 95)
        
        # Store a simplified result
        st.session_state[f"result_{assessment_id}"] = {
            "score": score,
            "feedback": "Your project demonstrates good understanding of the core concepts. The implementation is functional and meets most of the requirements. Consider adding more detail to your documentation and explanation of your approach."
        }
    
    # Generate personalized recommendations
    assessment_results = {
        assessment_id: {
            "score": st.session_state[f"result_{assessment_id}"].get("score", 0),
            "subject": assessment['subject']
        }
    }
    
    st.session_state[f"recommendations_{assessment_id}"] = ai_engine.generate_personalized_feedback(
        assessment_results, student_data
    )
    
    st.success("Assessment submitted successfully!")
    st.rerun()

def show_feedback(assessment, student_data):
    """Display feedback for a submitted assessment."""
    
    assessment_id = assessment['id']
    result = st.session_state.get(f"result_{assessment_id}", {})
    recommendations = st.session_state.get(f"recommendations_{assessment_id}", {})
    
    st.success("Assessment Submitted")
    
    # Display score
    score = result.get("score", 0)
    st.subheader("Your Result")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        # Display score as a gauge
        import plotly.graph_objects as go
        
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=score,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Score"},
            gauge={
                'axis': {'range': [0, 100]},
                'bar': {'color': "#4B8BF4"},
                'steps': [
                    {'range': [0, 60], 'color': "#FF6B6B"},
                    {'range': [60, 80], 'color': "#FFD166"},
                    {'range': [80, 100], 'color': "#06D6A0"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 70
                }
            }
        ))
        
        fig.update_layout(
            height=300,
            margin=dict(l=20, r=20, t=50, b=20),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        st.plotly_chart(fig)
    
    with col2:
        # Show detailed feedback based on assessment type
        st.subheader("Feedback")
        
        if assessment['type'] in ["Quiz", "Test"]:
            st.write(f"**Score:** {score}%")
            st.write(f"**Correct Answers:** {result.get('correct_count', 0)}/{result.get('total_questions', 0)}")
            
            # Display feedback for each question
            feedback = result.get("feedback", {})
            for question_id, question_feedback in feedback.items():
                with st.expander(f"Question {question_id[1:]}"):
                    st.write(question_feedback)
        
        elif assessment['type'] == "Essay":
            st.write(f"**Overall Score:** {score}%")
            
            # Display criteria scores
            criteria_scores = result.get("criteria_scores", {})
            for criterion, criterion_score in criteria_scores.items():
                st.write(f"**{criterion}:** {criterion_score}%")
            
            # Display detailed feedback
            st.subheader("Detailed Feedback")
            st.write(result.get("detailed_feedback", "No detailed feedback available."))
        
        elif assessment['type'] in ["Project", "Lab"]:
            st.write(f"**Score:** {score}%")
            st.write(result.get("feedback", "No feedback available."))
    
    # Personalized recommendations section
    st.subheader("Personalized Recommendations")
    
    # Strengths
    if recommendations.get("strengths"):
        st.write("**Strengths:**")
        for strength in recommendations["strengths"]:
            st.success(strength)
    
    # Areas for improvement
    if recommendations.get("areas_for_improvement"):
        st.write("**Areas for Improvement:**")
        for area in recommendations["areas_for_improvement"]:
            st.info(area)
    
    # Recommendations
    if recommendations.get("recommendations"):
        st.write("**Recommended Next Steps:**")
        for recommendation in recommendations["recommendations"]:
            st.write(f"- {recommendation}")
    
    # Option to retake or return to dashboard
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Retake Assessment"):
            # Reset assessment state
            del st.session_state[f"submitted_{assessment_id}"]
            del st.session_state[f"submitting_{assessment_id}"]
            if f"result_{assessment_id}" in st.session_state:
                del st.session_state[f"result_{assessment_id}"]
            if f"recommendations_{assessment_id}" in st.session_state:
                del st.session_state[f"recommendations_{assessment_id}"]
            st.rerun()
    
    with col2:
        if st.button("Return to Dashboard"):
            st.session_state.page = "dashboard"
            st.rerun()

if __name__ == "__main__":
    app()
