import streamlit as st
import time
import random
from utils.ai_assessment import AIAssessmentEngine
from utils.openai_integration import check_openai_available, generate_writing_tips
from data.sample_assessments import get_assessment_by_id
from data.student_data import get_student_data

# Custom CSS for enhanced visual styling
st.markdown("""
<style>
    .ai-badge {
        display: flex;
        align-items: center;
        margin-bottom: 1.5rem;
        padding: 0.8rem;
        border-radius: 0.5rem;
    }
    
    .ai-badge-icon {
        height: 32px;
        width: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 1rem;
        font-size: 1.2rem;
        color: white;
    }
    
    .essay-prompt-card {
        background-color: white;
        border-radius: 0.5rem;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        border-left: 4px solid #4B8BF4;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    
    .essay-prompt-title {
        font-weight: 600;
        font-size: 1.05rem;
        margin-bottom: 0.8rem;
        color: #333;
    }
    
    .essay-prompt-text {
        font-size: 1rem;
        margin-bottom: 1rem;
        color: #333;
        line-height: 1.5;
    }
    
    .prompt-info-box {
        background-color: #f8f9fa;
        border-radius: 0.5rem;
        padding: 0.8rem;
        font-size: 0.9rem;
        color: #555;
    }
    
    .info-icon {
        color: #4B8BF4;
        margin-right: 0.5rem;
    }
    
    .criteria-list {
        margin: 0.3rem 0 0 1.2rem;
        padding: 0;
    }
    
    .feedback-card {
        background-color: white;
        border-radius: 0.5rem;
        padding: 1.5rem;
        margin: 1.5rem 0;
        border-left: 4px solid #4B8BF4;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    
    .feedback-header {
        display: flex;
        align-items: center;
        margin-bottom: 1.5rem;
    }
    
    .score-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
        font-weight: 700;
        margin-right: 1.5rem;
    }
    
    .score-circle-high {
        background-color: #e6f4ea;
        color: #34A853;
        border: 2px solid #34A853;
    }
    
    .score-circle-medium {
        background-color: #fef7e0;
        color: #FBBC05;
        border: 2px solid #FBBC05;
    }
    
    .score-circle-low {
        background-color: #fce8e6;
        color: #EA4335;
        border: 2px solid #EA4335;
    }
    
    .feedback-title {
        font-size: 1.4rem;
        font-weight: 600;
        color: #333;
        margin: 0;
    }
    
    .feedback-subtitle {
        font-size: 1rem;
        color: #666;
        margin-top: 0.3rem;
    }
    
    .criteria-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.8rem 0;
        border-bottom: 1px solid #f0f2f6;
    }
    
    .criteria-name {
        font-weight: 500;
        color: #333;
    }
    
    .criteria-score {
        font-weight: 600;
        padding: 0.3rem 0.8rem;
        border-radius: 1rem;
    }
    
    .strength-item {
        display: flex;
        align-items: flex-start;
        margin-bottom: 0.8rem;
        padding-left: 0.8rem;
        border-left: 3px solid #34A853;
    }
    
    .improvement-item {
        display: flex;
        align-items: flex-start;
        margin-bottom: 0.8rem;
        padding-left: 0.8rem;
        border-left: 3px solid #FBBC05;
    }
    
    .tip-item-icon {
        margin-right: 0.8rem;
        color: #4B8BF4;
        font-size: 1.1rem;
    }
</style>
""", unsafe_allow_html=True)

def app():
    """Essay assessment page with AI-powered grading."""
    
    # Page header
    st.markdown("""
    <div style="background-color: #4B8BF4; padding: 2rem; border-radius: 0.8rem; margin-bottom: 2rem; 
        background-image: linear-gradient(135deg, #4B8BF4, #3267d6); color: white; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
        <h1 style="margin: 0; color: white; font-size: 2.2rem;">AI-Powered Essay Assessment</h1>
        <p style="color: rgba(255, 255, 255, 0.9); margin: 0.5rem 0 0 0; font-size: 1.1rem;">
            Get detailed feedback and personalized writing tips from our AI assessment system
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if OpenAI integration is available
    openai_available = check_openai_available()
    ai_status_color = "#34A853" if openai_available else "#FBBC05"
    
    # AI availability status badge
    st.markdown(f"""
    <div class="ai-badge" style="background-color: {'#e6f4ea' if openai_available else '#fef7e0'}; 
        border-left: 4px solid {ai_status_color};">
        <div class="ai-badge-icon" style="background-color: {ai_status_color};">
            {'✓' if openai_available else '!'}
        </div>
        <div>
            <div style="font-weight: 600; color: {ai_status_color};">
                {"AI Assessment Engine Active" if openai_available else "AI Assessment Engine Limited"}
            </div>
            <div style="color: #555; font-size: 0.9rem;">
                {"Advanced essay analysis and personalized feedback are available" if openai_available else 
                "Basic essay assessment is available - add OpenAI API key for advanced features"}
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Essay prompt section
    st.markdown("""
    <div class="essay-prompt-card">
        <div class="essay-prompt-title">Essay Prompt</div>
        <div class="essay-prompt-text">
            Analyze the impact of artificial intelligence on education in the 21st century. 
            Discuss both potential benefits and challenges, and provide specific examples of AI applications 
            in educational settings. Consider ethical implications and suggest guidelines for responsible 
            implementation of AI in education.
        </div>
        <div class="prompt-info-box">
            <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                <span class="info-icon">ℹ️</span> 
                <span>Word count requirement: <strong>500-1000 words</strong></span>
            </div>
            <div style="display: flex; align-items: flex-start; margin-top: 0.5rem;">
                <span class="info-icon">📝</span>
                <span>
                    <strong>Grading Criteria:</strong><br>
                    <ul class="criteria-list">
                        <li>Content & Analysis (40%)</li>
                        <li>Organization & Structure (25%)</li>
                        <li>Language & Style (20%)</li>
                        <li>Citations & Research (15%)</li>
                    </ul>
                </span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Essay writing information
    with st.expander("How the AI evaluation works", expanded=False):
        st.markdown("""
        <div style="padding: 0.5rem 0;">
            <p style="margin-bottom: 0.8rem;">Our advanced AI evaluation system analyzes your essay across multiple dimensions:</p>
            <ul>
                <li><strong>Content Analysis:</strong> Evaluates the depth, relevance, and accuracy of your arguments</li>
                <li><strong>Structure Assessment:</strong> Examines organization, flow, and logical progression</li>
                <li><strong>Language Evaluation:</strong> Assesses clarity, style, vocabulary, and grammar</li>
                <li><strong>Critical Thinking:</strong> Measures analytical depth and original insights</li>
            </ul>
            <p style="margin-top: 0.8rem;">The AI provides specific, personalized feedback to help improve your writing skills.</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Essay input section
    essay_text = st.text_area(
        "Write your essay here:",
        height=350,
        help="Write a well-structured essay that addresses all aspects of the prompt.",
        key="ai_essay_input"
    )
    
    # Word count display with modern styling
    if essay_text:
        word_count = len(essay_text.split())
        word_min, word_max = 500, 1000
        
        # Color based on whether count is within range
        count_color = "#34A853" if word_min <= word_count <= word_max else "#FBBC05" if word_count < word_min else "#EA4335"
        
        # Visualize progress toward word count
        progress_pct = min(100, int((word_count / word_min) * 100)) if word_count < word_min else 100
        
        st.markdown(f"""
        <div style="margin: 1rem 0;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                <div style="font-size: 0.9rem; color: #555;">Word Count:</div>
                <div style="font-weight: 600; color: {count_color};">{word_count}/{word_min}-{word_max}</div>
            </div>
            <div style="background-color: #f0f2f6; height: 8px; border-radius: 4px; overflow: hidden;">
                <div style="height: 100%; width: {progress_pct}%; background-color: {count_color}; border-radius: 4px;"></div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Word count warnings
        if word_count < word_min:
            st.info(f"Your essay needs at least {word_min - word_count} more words to meet the minimum requirement.")
        elif word_count > word_max:
            st.warning(f"Your essay is {word_count - word_max} words over the maximum limit.")
    
    # Submit button with modern styling
    col1, col2 = st.columns([3, 1])
    with col1:
        submit_button = st.button("Submit Essay for AI Evaluation", type="primary", use_container_width=True)
    with col2:
        clear_button = st.button("Clear Essay", use_container_width=True)
        if clear_button:
            st.session_state.ai_essay_input = ""
            st.rerun()
    
    # AI evaluation section
    if submit_button and essay_text:
        with st.spinner("Analyzing your essay..."):
            # Initialize assessment engine
            ai_engine = AIAssessmentEngine()
            
            # Process the essay
            # We're using criteria weights for the AI evaluation
            criteria = {
                "Content & Analysis": 40,
                "Organization & Structure": 25,
                "Language & Style": 20,
                "Citations & Research": 15
            }
            
            # Show a progress animation for the AI analysis
            progress_placeholder = st.empty()
            for i in range(101):
                progress_placeholder.progress(i)
                time.sleep(0.01)
            progress_placeholder.empty()
            
            # Get essay evaluation from AI
            result = ai_engine.evaluate_essay(
                essay_text=essay_text,
                prompt="Analyze the impact of artificial intelligence on education in the 21st century.",
                criteria=criteria
            )
            
            # Extract results
            overall_score = result.get("overall_score", 75)
            criteria_scores = result.get("criteria_scores", {})
            strengths = result.get("strengths", [])
            areas_for_improvement = result.get("areas_for_improvement", [])
            detailed_feedback = result.get("detailed_feedback", "")
            
            # Determine score class for styling
            score_class = "score-circle-high" if overall_score >= 80 else "score-circle-medium" if overall_score >= 60 else "score-circle-low"
            
            # Display feedback card with results
            st.markdown("""
            <h2 style="margin: 2rem 0 1rem 0; color: #4B8BF4;">
                AI Assessment Results
            </h2>
            """, unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="feedback-card">
                <div class="feedback-header">
                    <div class="score-circle {score_class}">{overall_score}</div>
                    <div>
                        <h3 class="feedback-title">Essay Evaluation</h3>
                        <p class="feedback-subtitle">
                            {
                                "Excellent work! Your essay demonstrates strong understanding and analysis." 
                                if overall_score >= 80 else
                                "Good effort. Your essay shows solid understanding with some areas for improvement." 
                                if overall_score >= 60 else
                                "Your essay needs further development in several key areas."
                            }
                        </p>
                    </div>
                </div>
                
                <h4 style="margin: 1.5rem 0 0.8rem 0; color: #333;">Criteria Scores</h4>
                <div style="background-color: #f8f9fa; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1.5rem;">
            """, unsafe_allow_html=True)
            
            # Display criteria scores
            for criterion, score in criteria_scores.items():
                score_color_bg = "#e6f4ea" if score >= 80 else "#fef7e0" if score >= 60 else "#fce8e6"
                score_color_text = "#34A853" if score >= 80 else "#FBBC05" if score >= 60 else "#EA4335"
                
                st.markdown(f"""
                <div class="criteria-item">
                    <div class="criteria-name">{criterion}</div>
                    <div class="criteria-score" style="background-color: {score_color_bg}; color: {score_color_text};">
                        {score}/100
                    </div>
                </div>
                """, unsafe_allow_html=True)
            
            # End criteria section
            st.markdown("</div>", unsafe_allow_html=True)
            
            # Strengths and areas for improvement
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("""
                <h4 style="margin: 0.5rem 0 0.8rem 0; color: #34A853;">Strengths</h4>
                """, unsafe_allow_html=True)
                
                for strength in strengths:
                    st.markdown(f"""
                    <div class="strength-item">
                        <div>{strength}</div>
                    </div>
                    """, unsafe_allow_html=True)
            
            with col2:
                st.markdown("""
                <h4 style="margin: 0.5rem 0 0.8rem 0; color: #FBBC05;">Areas for Improvement</h4>
                """, unsafe_allow_html=True)
                
                for area in areas_for_improvement:
                    st.markdown(f"""
                    <div class="improvement-item">
                        <div>{area}</div>
                    </div>
                    """, unsafe_allow_html=True)
            
            # Detailed feedback
            st.markdown("""
            <h4 style="margin: 1.5rem 0 0.8rem 0; color: #333;">Detailed Feedback</h4>
            <div style="background-color: #f8f9fa; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1.5rem; color: #333; white-space: pre-line;">
            """, unsafe_allow_html=True)
            
            # Display detailed feedback (handling newlines properly)
            formatted_feedback = detailed_feedback.replace("\n", "<br>")
            st.markdown(f"{formatted_feedback}", unsafe_allow_html=True)
            
            # End detailed feedback section
            st.markdown("</div>", unsafe_allow_html=True)
            
            # Writing tips section
            st.markdown("""
            <h4 style="margin: 1.5rem 0 0.8rem 0; color: #4B8BF4;">Personalized Writing Tips</h4>
            """, unsafe_allow_html=True)
            
            # Get personalized writing tips
            writing_tips = generate_writing_tips("S1001")
            
            for i, tip in enumerate(writing_tips[:5]):
                st.markdown(f"""
                <div style="display: flex; align-items: flex-start; margin-bottom: 1rem; 
                    background-color: #f8f9fa; border-radius: 0.5rem; padding: 0.8rem;">
                    <div class="tip-item-icon">{i+1}.</div>
                    <div>{tip}</div>
                </div>
                """, unsafe_allow_html=True)
            
            # Close feedback card div
            st.markdown("</div>", unsafe_allow_html=True)
            
            # Provide options for next steps
            st.markdown("""
            <h4 style="margin: 1.5rem 0 0.8rem 0; color: #333;">Next Steps</h4>
            """, unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("Revise Essay", use_container_width=True):
                    st.session_state.show_tips = True
            
            with col2:
                if st.button("View Writing Resources", use_container_width=True):
                    st.session_state.show_resources = True
            
            with col3:
                if st.button("Submit Final Version", type="primary", use_container_width=True):
                    st.success("Essay submitted successfully!")
            
            # Display writing tips if requested
            if st.session_state.get("show_tips", False):
                with st.expander("Revision Strategies", expanded=True):
                    st.markdown("""
                    <div style="padding: 0.5rem 0;">
                        <p style="margin-bottom: 0.8rem;"><strong>Effective Revision Strategies:</strong></p>
                        <ol>
                            <li><strong>Address the content gaps</strong> identified in the feedback</li>
                            <li><strong>Reorganize</strong> your essay structure to improve flow</li>
                            <li>Work on <strong>transitions</strong> between paragraphs for better coherence</li>
                            <li>Strengthen your <strong>thesis statement</strong> and ensure it's clearly presented</li>
                            <li>Add <strong>specific examples</strong> to support your arguments</li>
                            <li>Review and improve your <strong>conclusion</strong> to reinforce key points</li>
                        </ol>
                    </div>
                    """, unsafe_allow_html=True)
            
            # Display writing resources if requested
            if st.session_state.get("show_resources", False):
                with st.expander("Writing Resources", expanded=True):
                    st.markdown("""
                    <div style="padding: 0.5rem 0;">
                        <p style="margin-bottom: 0.8rem;"><strong>Recommended Writing Resources:</strong></p>
                        <ul>
                            <li><strong>Purdue OWL:</strong> Comprehensive writing guides and resources</li>
                            <li><strong>Grammarly:</strong> Grammar and style checker</li>
                            <li><strong>Hemingway Editor:</strong> Helps simplify complex sentences</li>
                            <li><strong>Academic Phrasebank:</strong> Ready-made phrases for academic writing</li>
                            <li><strong>Citation Generators:</strong> APA, MLA, Chicago style formatting tools</li>
                        </ul>
                    </div>
                    """, unsafe_allow_html=True)

if __name__ == "__main__":
    app()