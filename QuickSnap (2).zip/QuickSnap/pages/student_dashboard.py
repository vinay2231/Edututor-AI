import streamlit as st
import pandas as pd
import plotly.express as px
from utils.visualization import create_progress_chart, create_engagement_chart
from utils.data_processing import DataProcessor
from data.student_data import get_student_data

def app():
    """Student dashboard page showing performance and personalized recommendations."""
    
    # Check if user is authenticated and is a student
    if not st.session_state.get('authenticated', False) or st.session_state.get('user_type') != 'student':
        st.warning("Please log in as a student to access this dashboard.")
        return
    
    # Get student data
    student_id = st.session_state.current_user
    student_data = get_student_data(student_id)
    
    if not student_data:
        st.error("Student data not found.")
        return
    
    # Initialize data processor
    data_processor = DataProcessor()
    student_stats = data_processor.calculate_student_statistics(student_data)
    
    # Page header
    st.title(f"Welcome to Your Dashboard, {student_data['first_name']}!")
    
    # Dashboard layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Overview statistics
        st.subheader("Your Performance")
        
        metric_col1, metric_col2, metric_col3 = st.columns(3)
        
        with metric_col1:
            st.metric("Overall Average", f"{student_stats['average_score']:.1f}%")
        
        with metric_col2:
            st.metric("Completed Assessments", student_stats['completed_assessments'])
        
        with metric_col3:
            st.metric("Completion Rate", f"{student_stats['completion_rate']:.1f}%")
        
        # Performance radar chart
        st.subheader("Subject Performance")
        fig = create_progress_chart(student_data)
        st.plotly_chart(fig, use_container_width=True)
        
        # Recommendations section
        st.subheader("Personalized Recommendations")
        recommendations = data_processor.generate_student_recommendations(student_data)
        
        for i, rec in enumerate(recommendations):
            with st.expander(f"{rec['description']}"):
                st.write(rec['details'])
                
                # Add action button if appropriate
                if rec['type'] == 'improvement':
                    st.button(f"View {rec['subject']} Resources", key=f"res_{i}")
                elif rec['type'] == 'engagement':
                    st.button("View Pending Assignments", key=f"assign_{i}")
                elif rec['type'] == 'enrichment':
                    st.button(f"Explore Advanced {rec['subject']}", key=f"adv_{i}")
    
    with col2:
        # Recent activity
        st.subheader("Recent Activity")
        
        # Mock recent activity
        activities = [
            {"type": "assessment", "name": "Math Quiz", "date": "2 days ago", "result": "85%"},
            {"type": "material", "name": "Science Reading", "date": "4 days ago", "result": "Completed"},
            {"type": "feedback", "name": "Essay Feedback", "date": "1 week ago", "result": "Reviewed"},
            {"type": "assessment", "name": "History Test", "date": "2 weeks ago", "result": "78%"}
        ]
        
        for activity in activities:
            activity_type = activity["type"]
            icon = "📝" if activity_type == "assessment" else "📚" if activity_type == "material" else "💬"
            
            st.write(f"{icon} **{activity['name']}**")
            st.write(f"_{activity['date']}_ • {activity['result']}")
            st.write("---")
        
        # Upcoming deadlines
        st.subheader("Upcoming Deadlines")
        
        # Mock deadlines
        deadlines = [
            {"name": "Science Project", "due": "Tomorrow", "status": "Not Started"},
            {"name": "Math Homework", "due": "In 3 days", "status": "In Progress"},
            {"name": "History Essay", "due": "Next Week", "status": "Not Started"}
        ]
        
        for deadline in deadlines:
            status_color = "🔴" if deadline["status"] == "Not Started" else "🟠" if deadline["status"] == "In Progress" else "🟢"
            st.write(f"**{deadline['name']}** • Due: {deadline['due']}")
            st.write(f"{status_color} {deadline['status']}")
            st.write("---")
    
    # Engagement section
    st.subheader("Your Engagement")
    
    # Mock engagement data
    engagement_data = {
        "weekly_logins": {
            "Week 1": 5,
            "Week 2": 4,
            "Week 3": 7,
            "Week 4": 6,
            "Week 5": 8
        },
        "time_spent": {
            "Monday": 45,
            "Tuesday": 30,
            "Wednesday": 60,
            "Thursday": 25,
            "Friday": 40
        }
    }
    
    engagement_fig = create_engagement_chart(engagement_data)
    st.plotly_chart(engagement_fig, use_container_width=True)
    
    # Learning path progress
    st.subheader("Your Learning Path Progress")
    
    # Mock learning path data
    current_modules = [
        {"name": "Algebra Fundamentals", "progress": 75, "status": "In Progress"},
        {"name": "Scientific Method", "progress": 100, "status": "Completed"},
        {"name": "Essay Writing", "progress": 60, "status": "In Progress"}
    ]
    
    # Display current modules as a progress dashboard
    for module in current_modules:
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.write(f"**{module['name']}**")
            st.progress(module['progress'] / 100)
        
        with col2:
            st.write(f"{module['progress']}% complete")
            
            if module['status'] == 'Completed':
                st.success("Completed")
            else:
                st.info("In Progress")
                st.button("Continue", key=f"continue_{module['name']}")
        
        st.write("---")
    
    # Action center
    st.subheader("Quick Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.button("Start New Assessment")
    
    with col2:
        st.button("Review Feedback")
    
    with col3:
        st.button("Explore Learning Resources")

if __name__ == "__main__":
    app()
