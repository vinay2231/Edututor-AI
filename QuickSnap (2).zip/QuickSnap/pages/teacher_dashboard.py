import streamlit as st
import pandas as pd
import plotly.express as px
from utils.data_processing import DataProcessor
from data.student_data import get_all_students
from data.sample_assessments import get_available_assessments

def app():
    """Teacher dashboard showing class performance, student analytics, and assessment management."""
    
    # Check if user is authenticated and is a teacher
    if not st.session_state.get('authenticated', False) or st.session_state.get('user_type') != 'teacher':
        st.warning("Please log in as a teacher to access this dashboard.")
        return
    
    # Initialize data processor
    data_processor = DataProcessor()
    
    # Get student data
    students = get_all_students()
    class_stats = data_processor.calculate_class_statistics(students)
    
    # Page header
    st.title("Teacher Dashboard")
    
    # Dashboard layout
    tab1, tab2, tab3 = st.tabs(["Class Overview", "Student Analytics", "Assessment Management"])
    
    with tab1:
        # Class statistics
        st.subheader("Class Performance Overview")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Class Average", f"{class_stats['class_average']:.1f}%")
        
        with col2:
            st.metric("Completion Rate", f"{class_stats['completion_rate']:.1f}%")
        
        with col3:
            st.metric("Students At Risk", class_stats['at_risk_count'])
        
        with col4:
            st.metric("At Risk %", f"{class_stats['at_risk_percentage']:.1f}%")
        
        # Subject performance chart
        st.subheader("Average Performance by Subject")
        subject_data = {
            'Subject': list(class_stats['subject_averages'].keys()),
            'Average Score': list(class_stats['subject_averages'].values())
        }
        fig = data_processor.create_subject_performance_chart(subject_data)
        st.plotly_chart(fig, use_container_width=True)
        
        # Student list
        st.subheader("Student Overview")
        
        # Create a table of students
        student_table_data = []
        for student in students:
            avg_score = sum([
                student['performance']['math'], 
                student['performance']['science'],
                student['performance']['language_arts'],
                student['performance']['history']
            ]) / 4
            
            status = "At Risk" if avg_score < 70 else "On Track" if avg_score < 90 else "Excellent"
            
            student_table_data.append({
                "Name": f"{student['first_name']} {student['last_name']}",
                "ID": student['id'],
                "Average": f"{avg_score:.1f}%",
                "Completed": student['completed_assessments'],
                "Status": status
            })
        
        student_df = pd.DataFrame(student_table_data)
        
        # Color the status column
        def color_status(val):
            if val == "At Risk":
                return "background-color: #FFCCCC"
            elif val == "Excellent":
                return "background-color: #CCFFCC"
            else:
                return ""
        
        # Display the styled table
        st.dataframe(student_df.style.applymap(color_status, subset=['Status']), 
                    use_container_width=True)
        
        # Recent assessments
        st.subheader("Recent Assessments")
        
        assessments = get_available_assessments()
        for assessment in assessments[:3]:  # Show only the 3 most recent
            with st.expander(f"{assessment['title']} - {assessment['subject']}"):
                st.write(f"**Due Date:** {assessment['due_date']}")
                st.write(f"**Type:** {assessment['type']}")
                
                # Mock completion statistics
                completed = assessment.get('completed', 18)
                total = 28  # Total students
                st.write(f"**Completion:** {completed}/{total} students")
                st.progress(completed/total)
                
                if completed > 0:
                    avg_score = assessment.get('avg_score', 76)
                    st.write(f"**Average Score:** {avg_score}%")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.button("View Details", key=f"view_{assessment['id']}")
                with col2:
                    st.button("Grade Submissions", key=f"grade_{assessment['id']}")
    
    with tab2:
        # Student selector
        st.subheader("Student Performance Analytics")
        
        student_names = [f"{s['first_name']} {s['last_name']}" for s in students]
        selected_student = st.selectbox("Select Student", student_names)
        selected_index = student_names.index(selected_student)
        student = students[selected_index]
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.write(f"**Name:** {student['first_name']} {student['last_name']}")
            st.write(f"**ID:** {student['id']}")
            st.write(f"**Grade Level:** {student['grade_level']}")
            st.write(f"**Completed Assessments:** {student['completed_assessments']}")
            
            # Learning profile
            st.subheader("Learning Profile")
            st.write(f"**Primary Learning Style:** {student['learning_style']}")
            st.write("**Subject Engagement:**")
            for subject, level in student['engagement'].items():
                st.write(f"- {subject.capitalize()}: {level}/10")
        
        with col2:
            # Performance chart
            st.subheader("Subject Performance")
            performance_data = {
                'Subject': ['Math', 'Science', 'Language Arts', 'History'],
                'Score': [
                    student['performance']['math'],
                    student['performance']['science'],
                    student['performance']['language_arts'],
                    student['performance']['history']
                ]
            }
            fig = data_processor.create_subject_performance_chart(performance_data)
            st.plotly_chart(fig, use_container_width=True)
        
        # Performance over time (mock data)
        st.subheader("Performance Trend")
        
        progress_data = {
            'Month': ['January', 'February', 'March', 'April', 'May'],
            'Math': [65, 68, 72, 75, student['performance']['math']],
            'Science': [70, 72, 75, 78, student['performance']['science']],
            'Language Arts': [80, 82, 80, 83, student['performance']['language_arts']],
            'History': [75, 77, 80, 78, student['performance']['history']]
        }
        fig = data_processor.create_progress_over_time_chart(progress_data)
        st.plotly_chart(fig, use_container_width=True)
        
        # Assessment history table
        st.subheader("Assessment History")
        
        # Mock assessment history
        history_data = [
            {"assessment": "Math Quiz - Algebra", "date": "2023-05-10", "score": 85, "class_avg": 78},
            {"assessment": "Science Lab - Chemistry", "date": "2023-05-05", "score": 78, "class_avg": 75},
            {"assessment": "Language Arts - Essay", "date": "2023-04-28", "score": 90, "class_avg": 82},
            {"assessment": "History - Civil War Test", "date": "2023-04-20", "score": 82, "class_avg": 80}
        ]
        
        history_df = pd.DataFrame(history_data)
        
        # Add a column for comparison to class average
        history_df['vs_avg'] = history_df.apply(
            lambda row: f"{row['score'] - row['class_avg']:+.1f}%", axis=1
        )
        
        # Display the table
        st.dataframe(history_df, use_container_width=True)
        
        # AI-generated insights and recommendations
        st.subheader("AI Insights")
        
        # Generate insights based on student performance
        avg_score = sum([
            student['performance']['math'], 
            student['performance']['science'],
            student['performance']['language_arts'],
            student['performance']['history']
        ]) / 4
        
        lowest_subject = min(student['performance'].items(), key=lambda x: x[1])
        highest_subject = max(student['performance'].items(), key=lambda x: x[1])
        
        with st.expander("Performance Insights"):
            st.write(f"**Overall Performance:** {avg_score:.1f}%")
            st.write(f"**Strongest Subject:** {highest_subject[0].capitalize()} ({highest_subject[1]}%)")
            st.write(f"**Needs Improvement:** {lowest_subject[0].capitalize()} ({lowest_subject[1]}%)")
            
            if avg_score < 70:
                st.warning("This student is at risk and requires intervention.")
            elif avg_score > 90:
                st.success("This student is performing excellently and may benefit from enrichment activities.")
            else:
                st.info("This student is performing adequately.")
        
        with st.expander("Recommended Actions"):
            if avg_score < 70:
                st.write("1. Schedule one-on-one tutoring sessions")
                st.write("2. Provide additional resources for self-study")
                st.write("3. Consider a parent-teacher conference")
                st.write("4. Implement weekly progress check-ins")
            elif lowest_subject[1] < 75:
                st.write(f"1. Provide additional {lowest_subject[0].capitalize()} resources")
                st.write("2. Consider peer tutoring or group study")
                st.write("3. Offer alternative assessment formats")
            else:
                st.write("1. Provide enrichment activities in areas of strength")
                st.write("2. Encourage peer tutoring participation")
                st.write("3. Consider advanced material or special projects")
        
        # Send message or notes
        st.subheader("Teacher Notes")
        
        note_text = st.text_area("Add notes about this student", height=100)
        if st.button("Save Notes"):
            st.success("Notes saved successfully.")
    
    with tab3:
        # Assessment management
        st.subheader("Assessment Management")
        
        subtab1, subtab2 = st.tabs(["Active Assessments", "Create New Assessment"])
        
        with subtab1:
            assessments = get_available_assessments()
            for assessment in assessments:
                with st.expander(f"{assessment['title']} - {assessment['subject']}"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.write(f"**Due Date:** {assessment['due_date']}")
                        st.write(f"**Type:** {assessment['type']}")
                        st.write(f"**Estimated Time:** {assessment['estimated_time']} minutes")
                        
                        status = "Active" if assessment.get('status', 'active') == 'active' else "Closed"
                        st.write(f"**Status:** {status}")
                    
                    with col2:
                        # Mock completion statistics
                        completed = assessment.get('completed', 18)
                        total = 28  # Total students
                        st.write(f"**Completion:** {completed}/{total} students")
                        st.progress(completed/total)
                        
                        if completed > 0:
                            avg_score = assessment.get('avg_score', 76)
                            st.write(f"**Average Score:** {avg_score}%")
                    
                    # Action buttons
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.button("View Details", key=f"details_{assessment['id']}")
                    
                    with col2:
                        st.button("Grade Submissions", key=f"submissions_{assessment['id']}")
                    
                    with col3:
                        if status == "Active":
                            st.button("Close Assessment", key=f"close_{assessment['id']}")
                        else:
                            st.button("Reopen Assessment", key=f"reopen_{assessment['id']}")
        
        with subtab2:
            # Assessment creation form
            st.write("Create a new assessment for your students")
            
            assessment_title = st.text_input("Assessment Title")
            
            col1, col2 = st.columns(2)
            
            with col1:
                subject = st.selectbox("Subject", ["Math", "Science", "Language Arts", "History"])
                assessment_type = st.selectbox("Assessment Type", ["Quiz", "Test", "Essay", "Project", "Lab"])
            
            with col2:
                due_date = st.date_input("Due Date")
                estimated_time = st.slider("Estimated Time (minutes)", 5, 120, 30)
            
            # Assessment description
            description = st.text_area("Description", placeholder="Enter a description of the assessment...")
            
            # Content based on assessment type
            if assessment_type in ["Quiz", "Test"]:
                st.subheader("Questions")
                
                with st.expander("Question 1"):
                    q1_text = st.text_area("Question", key="q1")
                    q1_type = st.selectbox("Question Type", ["Multiple Choice", "True/False", "Short Answer"], key="q1_type")
                    
                    if q1_type == "Multiple Choice":
                        st.text_input("Option A", key="q1_a")
                        st.text_input("Option B", key="q1_b")
                        st.text_input("Option C", key="q1_c")
                        st.text_input("Option D", key="q1_d")
                        st.selectbox("Correct Answer", ["A", "B", "C", "D"], key="q1_correct")
                    elif q1_type == "True/False":
                        st.selectbox("Correct Answer", ["True", "False"], key="q1_tf")
                    elif q1_type == "Short Answer":
                        st.text_area("Sample Answer (for AI grading)", key="q1_sample")
                
                st.button("+ Add Question")
            
            elif assessment_type == "Essay":
                st.subheader("Essay Parameters")
                st.text_area("Essay Prompt")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.number_input("Minimum Word Count", min_value=100, value=500)
                with col2:
                    st.number_input("Maximum Word Count", min_value=100, value=1000)
                
                st.subheader("Grading Rubric")
                st.text_area("Rubric Criteria", 
                            placeholder="Enter criteria for grading, e.g.:\n- Thesis Statement (20%)\n- Evidence Quality (30%)\n- Organization (25%)\n- Grammar/Mechanics (25%)")
            
            elif assessment_type in ["Project", "Lab"]:
                st.subheader("Project/Lab Details")
                st.text_area("Instructions")
                st.text_area("Deliverables")
                st.text_area("Evaluation Criteria")
                
                st.checkbox("Allow File Uploads")
                st.checkbox("Enable Group Submissions")
            
            # AI grading options
            st.subheader("AI Assessment Settings")
            
            ai_grading = st.checkbox("Enable AI Grading", value=True)
            
            if ai_grading:
                st.checkbox("Generate Personalized Feedback", value=True)
                st.checkbox("Provide Improvement Suggestions", value=True)
                st.slider("Feedback Detail Level", 1, 5, 3, 
                         help="1 = Brief feedback, 5 = Detailed analysis")
            
            # Create button
            if st.button("Create Assessment"):
                if assessment_title and description:
                    st.success(f"Assessment '{assessment_title}' created successfully!")
                else:
                    st.error("Please fill in all required fields.")

if __name__ == "__main__":
    app()
